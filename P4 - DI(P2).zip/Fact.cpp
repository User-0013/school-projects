#include "Fact.h"

Fact::Fact() {}
Fact::Fact(Lexer& lexer)
{
	parseFact(lexer);
}
Fact::~Fact() {}

void Fact::parseFact(Lexer& lexer)
{
	Id id(lexer);
	factName = id.toString();
	lexer.match(LEFT_PAREN);
	DLString string1(lexer);
	strings.push_back(string1);
	while (true)
	{
		try
		{
			lexer.match(COMMA);
			DLString string2(lexer);
			strings.push_back(string2);
		}
		catch (Token error)
		{
			if (error.getType() == RIGHT_PAREN)
			{
				break;
			}
			else
			{
				throw error;
			}
		}
	}
	lexer.match(RIGHT_PAREN);
	lexer.match(PERIOD);
}

void Fact::toString(string& result)
{
	result += factName + "(";
	for (unsigned int counter = 0; counter < strings.size() - 1; counter++)
	{
		result += strings[counter].toString() + ",";
	}
	result += strings.back().toString() + ").";
}

void Fact::getDomain(set<string>& domain)
{
	for (unsigned int counter = 0; counter < strings.size(); counter++)
	{
		domain.emplace(strings[counter].toString());
	}
}

vector<DLString> Fact::getStrings()
{
	return strings;
}

string Fact::getFactName()
{
	return factName;
}