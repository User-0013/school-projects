#include"Tuple.h"

Tuple::Tuple() {}
Tuple::~Tuple() {}

string Tuple::toString() const
{
	stringstream stream;
	for (unsigned int counter = 0; counter < this->size(); counter++)
	{
		stream << this->at(counter) << " ";
	}
	return stream.str();
}
