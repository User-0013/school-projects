#include "Lexer.h"
#include "Parser.h"
#include "Interpreter.h"

using namespace std;

int main(/*int argv, char* argc[]*/)
{
	Lexer lex("ex44.txt");
	DatalogProgram datalogProg(lex);
	datalogProg.parseDatalogProgram(lex);
	Interpreter interpreter = Interpreter(datalogProg); //construct the interpreter with the given datalog program
	interpreter.ansQueries(); //answers the queries after evaluating the rules
	return 0;
}