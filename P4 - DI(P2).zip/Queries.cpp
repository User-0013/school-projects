#include "Queries.h"

Queries::Queries() {}
Queries::Queries(Lexer& lexer)
{
	parseQueries(lexer);
}
Queries::~Queries() {}

void Queries::parseQueries(Lexer& lexer)
{
	int loopCounter = 0; //checks to make sure loop went at least one time
	lexer.match(QUERIES);
	lexer.match(COLON);
	do
	{
		try
		{
			Query query(lexer);
			queries.push_back(query);
			loopCounter++;
		}
		catch (Token error)
		{
			if (loopCounter >= 1) //indicates one or more queries were present
			{
				break;
			}
			else
			{
				throw error;
			}
		}
	} while (true);
}

void Queries::toString(string& result)
{
	result += "Queries(";
	result += to_string(queries.size());
	result += "):\n";
	for (unsigned int counter = 0; counter < queries.size(); counter++)
	{
		string queryResult;
		queries[counter].toString(queryResult);
		result += "  ";
		result += queryResult + "\n";
		queryResult.clear();
	}
}

vector<Query> Queries::getQuery()
{
	return queries;
}