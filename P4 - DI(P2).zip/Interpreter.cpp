#include "Interpreter.h"

Interpreter::Interpreter() : datalogProg(), database() {}
Interpreter::Interpreter(DatalogProgram program) : datalogProg(program), database()
{
	for (unsigned int counter = 0; counter < program.getSchemes()[0].getScheme().size(); counter++)
	{
		vector<string> schemeBody;
		for (unsigned int count = 1; count < program.getSchemes()[0].getScheme()[counter].getIds().size(); count++)
		{
			schemeBody.push_back(program.getSchemes()[0].getScheme()[counter].getIds()[count].toString());
		}
		Header newHead = Header(schemeBody);
		Relation rel(program.getSchemes()[0].getScheme()[counter].getIds()[0].toString(), newHead);
		database.insert(pair<string, Relation>(rel.getTableName(), rel));
	}
	for (unsigned int counter = 0; counter < program.getFacts().size(); counter++)
	{
		Tuple tuple;
		for (unsigned int count = 0; count < program.getFacts()[0].getFact().size(); count++)
		{
			for (unsigned int coun = 0; coun < program.getFacts()[0].getFact()[count].getStrings().size(); coun++)
			{
				tuple.push_back(program.getFacts()[0].getFact()[count].getStrings()[coun].toString());
			}
			database[program.getFacts()[0].getFact()[count].getFactName()].addTuple(tuple);
			tuple.clear();
		}
	}
	//vector<Relation> evaldRules;
	//vector<HeadPredicate> headPreds;
	bool chgd = true; //boolean to check if the database has been updated
	unsigned int timesPassed = 0; //number of times our fixed-point algorithm has executed
	unsigned int preCoun = 0; //pre-count of tuples in database
	while (chgd)
	{
		for (map<string, Relation>::iterator it = database.begin(); it != database.end(); ++it)
		{
			preCoun += it->second.getSizeOfTuples();
		}
		for (unsigned int counter = 0; counter < program.getRules().size(); counter++)
		{
			for (unsigned int count = 0; count < program.getRules()[0].getRule().size(); count++)
			{
				Relation temp = evalRule(program.getRules()[0].getRule()[count]->getPreds(), program.getRules()[0].getRule()[count]->getHeadPreds().front());
				database[program.getRules()[0].getRule()[count]->getHeadPreds().front().getIds().front().toString()] =
					uni(database[program.getRules()[0].getRule()[count]->getHeadPreds().front().getIds().front().toString()], temp);
				//headPreds.push_back(program.getRules()[0].getRule()[count]->getHeadPreds().front());
			}
		}
		evalRules(timesPassed, chgd, preCoun);
		//evaldRules.clear();
		//headPreds.clear();
	}
	cout << "Schemes populated after " << timesPassed << " passes through the Rules." << endl;
}
Interpreter::~Interpreter() {}

Relation Interpreter::ansQuery(vector<Predicate> preds, bool& qConst)
{
	string predName = preds[0].getPredName(); //get name of predicate as there is only one predicate in a query
	vector<pair<string, int>> constCol;
	vector<int> varCol;
	set<pair<int, string>> varColOrder;
	set<string> varSeenSoFar;
	map<string, vector<int>> colVarSeenBefore;
	Relation currRel = database[predName];
	colVarSeenBefore = selectInput(constCol, varCol, varSeenSoFar, preds);
	varColOrder = projectInput(colVarSeenBefore, varSeenSoFar);
	qConst = allConst(constCol, varCol);
	for (unsigned int counter = 0; counter < constCol.size(); counter++)
	{
		currRel = currRel.select(constCol[counter].second, constCol[counter].first);
	}
	if (varCol.size() != 0)
	{
		for (map<string, vector<int>>::iterator it = colVarSeenBefore.begin(); it != colVarSeenBefore.end(); ++it)
		{
			if (it->second.size() > 1)
			{
				for (unsigned int counter = 0; counter < it->second.size() - 1; counter++)
				{
					currRel = currRel.select(it->second[counter], it->second[counter + 1]);
				}
			}
			else
			{
				//currRel.select(it->second[0], it->first);
			}
		}
		currRel = currRel.project(varCol);
        int index = 0;
		for (set<pair<int, string>>::iterator it = varColOrder.begin(); it != varColOrder.end(); ++it)
		{
			currRel = currRel.rename(index, (*it).second);
            index++;
		}
	}
	return currRel;
}

void Interpreter::ansQueries()
{
	for (unsigned int counter = 0; counter < datalogProg.getQueries().size(); counter++)
	{
		for (unsigned int count = 0; count < datalogProg.getQueries()[counter].getQuery().size(); count++)
		{
			string query;
			bool qConst = false;
			datalogProg.getQueries()[counter].getQuery()[count].toString(query);
			Relation result = ansQuery(datalogProg.getQueries()[counter].getQuery()[count].getPreds(), qConst);
			cout << query;
			if (result.toString() != "")
			{
				if (qConst)
				{
					cout << " Yes(" << result.getSizeOfTuples() << ")" << endl;
				}
				else if (!qConst)
				{
					string temp;
					cout << " Yes(" << result.getSizeOfTuples() << ")" << endl;
					temp = result.toString();
					if (count == datalogProg.getQueries()[counter].getQuery().size() - 1)
					{
						temp.pop_back();
					}
					cout << temp;
				}
			}
			else
			{
				cout << " No" << endl;
			}
		}
	}
}

Relation Interpreter::evalRule(vector<Predicate*> preds, HeadPredicate headPred)
{
	bool qConst = false; //dummy variable for the ansQuery function
	vector<Predicate> nonptrPred; //vector of non-pointer predicates
	Relation relOne, relTwo, temp;
	vector<Relation> relsToJoin;
	for (unsigned int counter = 0; counter < preds.size(); counter++)
	{
		nonptrPred.push_back(*(preds[counter]));
		relOne = ansQuery(nonptrPred, qConst);
		relsToJoin.push_back(relOne);
		nonptrPred.clear();
		counter++;
		if (counter != preds.size())
		{
			nonptrPred.push_back(*(preds[counter]));
			relTwo = ansQuery(nonptrPred, qConst);
			relsToJoin.push_back(relTwo);
			nonptrPred.clear();
		}
	}
	temp = relsToJoin.front();
	for (unsigned int counter = 1; counter < relsToJoin.size(); counter++)
	{
		temp = naturalJoin(temp, relsToJoin[counter]);
	}
	vector<int> colProj;
	for (unsigned int counter = 1; counter < headPred.getIds().size(); counter++)
	{
		for (unsigned int count = 0; count < temp.getHeaderCol().size(); count++)
		{
			if (headPred.getIds()[counter].toString() == temp.getHeaderCol()[count])
			{
				colProj.push_back(count);
			}
		}
	}
	temp = temp.project(colProj);
	temp = temp.rename(database[headPred.getIds()[0].toString()].getHeaderCol());
	/*for (unsigned int counter = 0; counter < temp.getHeaderCol().size(); counter++)
	{
		temp.rename(counter, database[headPred.getIds()[0].toString()].getHeaderCol()[counter]);
	}*/

	return temp;
}

void Interpreter::evalRules(unsigned int& timesPassed, bool& chgd, unsigned int& preCoun)
{
	//bool chgd = true; //boolean to check if the database has been updated
	//unsigned int timesPassed = 0; //number of times our fixed-point algorithm has executed
	//unsigned int preCoun = 0; //pre-count of tuples in database
	unsigned int aftaCoun = 0; //after-counter of tuples in database
	//while (chgd)
	//{
		/*for (map<string, Relation>::iterator it = database.begin(); it != database.end(); ++it)
		{
			preCoun += it->second.getSizeOfTuples();
		}*/
		/*for (unsigned int counter = 0; counter < evaldRules.size(); counter++)
		{
			database[headPreds[counter].getIds()[0].toString()] = uni(database[headPreds[counter].getIds()[0].toString()], evaldRules[counter]);
		}*/
		for (map<string, Relation>::iterator it = database.begin(); it != database.end(); ++it)
		{
			aftaCoun += it->second.getSizeOfTuples();
		}
		timesPassed++;
		if (preCoun == aftaCoun)
		{
			chgd = false;
		}
		preCoun = 0;
		aftaCoun = 0;
	//}
	//cout << "Schemes populated after " << timesPassed << " passes through the Rules." << endl;
}

Relation Interpreter::uni()
{
	return Relation();
}

Relation Interpreter::naturalJoin(Relation first, Relation second)
{
	/*time_t tt;
	struct tm* ti;
	time(&tt);
	ti = localtime(&tt);
	cout << "Natural Join Start:" << asctime(ti) << endl;*/
	vector<int> varCol;
	set<string> varSeenSoFar;
	map<string, vector<int>> selectIn = selectInput(varCol, varSeenSoFar, first.getHeaderCol());
	Relation newFirst = selProjBeforeJoin(first, selectIn, varCol);
	selectIn.clear();
	varCol.clear();
	varSeenSoFar.clear();
	selectIn = selectInput(varCol, varSeenSoFar, second.getHeaderCol());
	Relation newSecond = selProjBeforeJoin(second, selectIn, varCol);
	selectIn = selectInput(varCol, varSeenSoFar, second.getHeaderCol());
	varSeenSoFar.clear();
	varCol.clear();
	selectIn.clear();
	vector<pair<int, int>> commonVar = sharedVar(first.getHeaderCol(), second.getHeaderCol());
	vector<string> newCols;
	Relation result;
	if (commonVar.size() != 0) //if the two relations share a variable
	{
		newCols = combHead(newFirst.getHeaderCol(), newSecond.getHeaderCol());
		selectIn = selectInput(varCol, varSeenSoFar, newCols);
		Header newHeader(newCols);
		Relation temp(newFirst.getTableName(), newHeader);
		temp = temp.project(varCol);
		result = temp;
		varCol = nonVarCol(commonVar, second.getHeaderCol().size());
		//result = combTuples(newFirst, newSecond, temp);
		//for (map<string, vector<int>>::iterator it = selectIn.begin(); it != selectIn.end(); ++it)
		//{
			//if (it->second.size() > 1)
			//{
				combTuples(newFirst, newSecond, result, commonVar, varCol);
				/*for (unsigned int counter = 0; counter < it->second.size() - 1; counter++)
				{
					result = result.select(it->second[counter], it->second[counter + 1]);
				}*/
			//}
		//}
		//result = result.project(varCol);
	}
	else if (commonVar.size() == 0) //else they don't share a variable, and join like normal
	{
		newCols = combHead(newFirst.getHeaderCol(), newSecond.getHeaderCol());
		Header newHeader(newCols);
		Relation temp(newFirst.getTableName(), newHeader);
		result = temp;
		combTuples(newFirst, newSecond, result);//***could be problem line***
	}
	/*time(&tt);
	ti = localtime(&tt);
	cout << "Natural Join End:" << asctime(ti) << endl;*/
	return result;
}

Relation Interpreter::uni(Relation first, Relation second)
{
	Relation result;
	if (first.getHeaderCol() == second.getHeaderCol()) //check if union compatible. if so continue
	{
		set<Tuple> tuplesSec = second.getTuples();
		Relation temp = first;
		for (set<Tuple>::iterator it = tuplesSec.begin(); it != tuplesSec.end(); ++it)
		{
			temp.addTuple((*it));
		}
		result = temp;
	}
	else if (first.getHeaderCol() != second.getHeaderCol() && first.getHeaderCol().size() == second.getHeaderCol().size())
		//else return an empty relation if there is not reordering to be done, else reorder first
	{
		Relation temp = reorderCol(second, first);
		result = uni(first, temp);
	}
	return result;
}

Relation Interpreter::selProjBeforeJoin(Relation rel, map<string, vector<int>> selectIn, vector<int> varCol)
{
	Relation result = rel;
	if (selectIn.size() != rel.getHeaderCol().size())
	{
		for (map<string, vector<int>>::iterator it = selectIn.begin(); it != selectIn.end(); ++it)
		{
			if (it->second.size() > 1)
			{
				for (unsigned int counter = 0; counter < it->second.size() - 1; counter++)
				{
					result = result.select(it->second[counter], it->second[counter + 1]);
				}
			}
			else
			{
                
			}
		}
		result = result.project(varCol);
	}
	return result;
}


map<string, vector<int>> Interpreter::selectInput(vector<pair<string, int>>& constCol, vector<int>& varCol, set<string>& varSeenSoFar, vector<Predicate> preds)
{
	map<string, vector<int>> colVarSeenBefore;
	for (unsigned int counter = 0; counter < preds.size(); counter++)
	{
		for (unsigned int count = 0; count < preds[counter].getPredicates().size(); count++)
		{
			string pred = preds[counter].getPredicates()[count];
			if (pred[0] == '\'')
			{
				constCol.push_back(pair<string, int>(pred, count));
			}
			else if (pred[0] != '\'')
			{
				if (varSeen(varSeenSoFar, pred))
				{
					colVarSeenBefore[pred].push_back(count);
				}
				else if (!varSeen(varSeenSoFar, pred))
				{
					colVarSeenBefore[pred].push_back(count);
					varCol.push_back(count);
					varSeenSoFar.insert(pred);
				}
			}
			pred.clear();
		}
	}
	return colVarSeenBefore;
}

map<string, vector<int>> Interpreter::selectInput(vector<int>& varCol, set<string>& varSeenSoFar, vector<string> columns)
{
	map<string, vector<int>> colVarSeenBefore;
	for (unsigned int counter = 0; counter < columns.size(); counter++)
	{
		string var = columns[counter];
		if (varSeen(varSeenSoFar, var))
		{
			colVarSeenBefore[var].push_back(counter);
		}
		else if (!varSeen(varSeenSoFar, var))
		{
			colVarSeenBefore[var].push_back(counter);
			varCol.push_back(counter);
			varSeenSoFar.insert(var);
		}
	}
	return colVarSeenBefore;
}

set<pair<int, string>> Interpreter::projectInput(map<string, vector<int>> colVarSeenBefore, set<string> varSeenSoFar)
{
	set<pair<int, string>> colToKeep;
	for (set<string>::iterator setIt = varSeenSoFar.begin(); setIt != varSeenSoFar.end(); ++setIt)
	{
		try
		{
			colToKeep.insert(pair<int, string>(colVarSeenBefore.at((*setIt)).front(), (*setIt)));
		}
		catch (exception out_of_range)
		{
			//the var requested doesn't exist
		}
	}
	return colToKeep;
}

DatalogProgram Interpreter::getDatalogProg()
{
	return datalogProg;
}

bool Interpreter::varSeen(set<string> varSeenSoFar, string pred)
{
	bool result = varSeenSoFar.count(pred);
	return result;
}

bool Interpreter::allConst(vector<pair<string, int>> constCol, vector<int> varCol)
{
	bool result = false;
	if (constCol.size() != 0 && varCol.size() == 0)
	{
		result = true;
	}
	else
	{
		result = false;
	}
	return result;
}

vector<pair<int, int>> Interpreter::sharedVar(vector<string> first, vector<string> second)
{
	bool shared = false;
	set<string> seenVarFirst;
	map<string, vector<int>> seenVarFirstCol;
	vector<pair<int, int>> sharedVarCol;
	for (unsigned int counter = 0; counter < first.size(); counter++)
	{
		seenVarFirst.insert(first[counter]);
		seenVarFirstCol[first[counter]].push_back(counter);
	}
	for (unsigned int counter = 0; counter < second.size(); counter++)
	{
		shared = varSeen(seenVarFirst, second[counter]);
		if (shared)
		{
			sharedVarCol.push_back(pair<int, int>(seenVarFirstCol[second[counter]].front(), counter));
		}
	}

	return sharedVarCol;
}

vector<string> Interpreter::combHead(vector<string> colsOne, vector<string> colsTwo)
{
	vector<string> result = colsOne;
	for (unsigned int counter = 0; counter < colsTwo.size(); counter++)
	{
		result.push_back(colsTwo[counter]);
	}
	return result;
}

void Interpreter::combTuples(Relation first, Relation second, Relation& newRel, vector<pair<int,int>> match, vector<int> nonVarCol)
{
	/*time_t tt;
	struct tm* ti;
	time(&tt);
	ti = localtime(&tt);
	cout << "Comb Tuples Start:" << asctime(ti) << endl;*/
	set<Tuple> firstTuples = first.getTuples();
	set<Tuple> secTuples = second.getTuples();
	for (set<Tuple>::iterator it = firstTuples.begin(); it != firstTuples.end(); ++it)
	{
		Tuple tuple = (*it);
		for (set<Tuple>::iterator itSec = secTuples.begin(); itSec != secTuples.end(); ++itSec)
		{
			tuple = (*it);
			if (isJoinable((*it), (*itSec), match))
			{
				for (unsigned int coun = 0; coun < nonVarCol.size(); coun++)
				{
					tuple.push_back((*itSec)[nonVarCol[coun]]);
				}
				/*bool good = false;
				for (unsigned int num = 0; num < match.size() - 1; num++)
				{
				if (tuple[match[num]] == tuple[match[num + 1]])
				{
				good = true;
				}
				}*/
				//tuple = projTuple(varCol, tuple);
				newRel.addTuple(tuple);
			}
			tuple.clear();
		}
	}
	/*time(&tt);
	ti = localtime(&tt);
	cout << "Comb Tuples End:" << asctime(ti) << endl;*/
}

void Interpreter::combTuples(Relation first, Relation second, Relation& newRel)
{
	/*time_t tt;
	struct tm* ti;
	time(&tt);
	ti = localtime(&tt);
	cout << "Comb Tuples 2 Start:" << asctime(ti) << endl;*/
	set<Tuple> firstTuples = first.getTuples();
	set<Tuple> secTuples = second.getTuples();
	for (set<Tuple>::iterator it = firstTuples.begin(); it != firstTuples.end(); ++it)
	{
		Tuple tuple = (*it);
		for (set<Tuple>::iterator itSec = secTuples.begin(); itSec != secTuples.end(); ++itSec)
		{
			tuple = (*it);
			for (unsigned int coun = 0; coun < (*itSec).size(); coun++)
			{
				tuple.push_back((*itSec)[coun]);
			}
			newRel.addTuple(tuple);
			tuple.clear();
		}
	}
	/*time(&tt);
	ti = localtime(&tt);
	cout << "Comb Tuples 2 Start:" << asctime(ti) << endl;*/
}

Tuple Interpreter::projTuple(vector<int> col, Tuple tuple)
{
	Tuple newTuple;
	for (unsigned int counter = 0; counter < col.size(); counter++)
	{
		newTuple.push_back(tuple[col[counter]]);
	}
	return newTuple;
}

bool Interpreter::isJoinable(Tuple first, Tuple second, vector<pair<int, int>> match)
{
	bool result = false;
	for (unsigned int counter = 0; counter < match.size(); counter++)
	{
		if (first[match[counter].first] == second[match[counter].second])
		{
			result = true;
		}
		else if (first[match[counter].first] != second[match[counter].second])
		{
			result = false;
		}
	}
	return result;
}

vector<int> Interpreter::nonVarCol(vector<pair<int, int>> commonVar, unsigned int tupleSize)
{
	vector<int> result;
	set<int> varCol;
	for (unsigned int counter = 0; counter < commonVar.size(); counter++)
	{
		varCol.insert(commonVar[counter].second);
	}
	for (unsigned int counter = 0; counter < tupleSize; counter++)
	{
		if (varCol.count(counter) != 1)
		{
			result.push_back(counter);
		}
	}
	return result;
}

Relation Interpreter::reorderCol(Relation toReorder, Relation reference)
{
	set<string> orig;
	set<string> toChg;
	map<string, vector<int>> colOrder;
	vector<pair<int, string>> reorder;
	vector<int> projReord;
	Relation result;

	for (unsigned int counter = 0; counter < reference.getHeaderCol().size(); counter++)
	{
		orig.insert(reference.getHeaderCol()[counter]);
		reorder.push_back(pair<int, string>(counter, reference.getHeaderCol()[counter]));
	}
	for (unsigned int counter = 0; counter < toReorder.getHeaderCol().size(); counter++)
	{
		string temp = toReorder.getHeaderCol()[counter];
		toChg.insert(temp);
		colOrder[temp].push_back(counter);
		temp.clear();
	}

	if (orig == toChg) //if two relations contain the same variables, reorder
	{
		Relation newRel = toReorder;
		for (unsigned int counter = 0; counter < reorder.size(); counter++)
		{
			projReord.push_back(colOrder[reorder[counter].second].front());
		}
		newRel = newRel.project(projReord);
		result = newRel;
	}
	else if (orig != toChg) //else if the two relations don't contain the same variables, return an empty relation
	{
		result = Relation();
	}
	return result;
}

void Interpreter::testOne()
{
	//TEST 1 - Natural join when relations share two columns, where the columns are in order, i.e. A,B,C and B,C,D to produce A,B,C,D
	string tableName = "SK";
	vector<string> columns = { "A", "B", "C" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'1\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'4\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'2\'");
	tuple.push_back("\'2\'");
	tuple.push_back("\'3\'");
	relOne.addTuple(tuple);
	tuple.clear();
	columns.clear();
	tableName = "SK";
	columns = { "B", "C", "D" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	tuple.push_back("\'3\'");
	tuple.push_back("\'4\'");
	tuple.push_back("\'5\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'6\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'7\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	Relation result = naturalJoin(relOne, relTwo);
	string expectedStr = "  A='1', B='3', C='4', D='5'\n";
	if (expectedStr == result.toString())
	{
		cout << "Test 1: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 1: Failed" << endl;
	}
}

void Interpreter::testTwo()
{
	//TEST 2 - Union when the two relations share some tuples. Tests for duplicates
	string tableName = "SK";
	vector<string> columns = { "A", "B", "C", "D" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'1\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'4\'");
	tuple.push_back("\'6\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'2\'");
	tuple.push_back("\'2\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'9\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'10\'");
	tuple.push_back("\'14\'");
	tuple.push_back("\'6\'");
	tuple.push_back("\'14\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'12\'");
	tuple.push_back("\'14\'");
	tuple.push_back("\'6\'");
	tuple.push_back("\'3\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'7\'");
	tuple.push_back("\'1\'");
	tuple.push_back("\'6\'");
	tuple.push_back("\'3\'");
	tuple.clear();
	columns.clear();
	tableName = "SK";
	columns = { "A", "B", "C", "D" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	tuple.push_back("\'3\'");
	tuple.push_back("\'4\'");
	tuple.push_back("\'5\'");
	tuple.push_back("\'4\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'15\'");
	tuple.push_back("\'1\'");
	tuple.push_back("\'15\'");
	tuple.push_back("\'9\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'10\'");
	tuple.push_back("\'14\'");
	tuple.push_back("\'6\'");
	tuple.push_back("\'14\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'12\'");
	tuple.push_back("\'14\'");
	tuple.push_back("\'6\'");
	tuple.push_back("\'3\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'7\'");
	tuple.push_back("\'1\'");
	tuple.push_back("\'6\'");
	tuple.push_back("\'3\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	Relation result = uni(relOne, relTwo);
	string expectedStr = "  A='1', B='3', C='4', D='6'\n";
	expectedStr += "  A='10', B='14', C='6', D='14'\n";
	expectedStr += "  A='12', B='14', C='6', D='3'\n";
	expectedStr += "  A='15', B='1', C='15', D='9'\n";
	expectedStr += "  A='2', B='2', C='3', D='9'\n";
	expectedStr += "  A='3', B='4', C='5', D='4'\n";
	expectedStr += "  A='7', B='1', C='6', D='3'\n";
	if (expectedStr == result.toString())
	{
		cout << "Test 2: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 2: Failed" << endl;
	}
}

void Interpreter::testThree()
{
	//TEST 3 - Natural Join when two relations share some columns, but are in slightly different order
	//i.e. cat,dog,fish and cat,fish,bird,bunny to produce cat,dog,fish,bird,bunny
	string tableName = "alpha";
	vector<string> columns = { "cat", "dog", "fish" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'1\'");
	tuple.push_back("\'2\'");
	tuple.push_back("\'5\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'1\'");
	tuple.push_back("\'4\'");
	tuple.push_back("\'1\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'2\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'2\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'3\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'2\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'6\'");
	tuple.push_back("\'7\'");
	tuple.push_back("\'4\'");
	relOne.addTuple(tuple);
	tuple.clear();
	columns.clear();
	tableName = "beta";
	columns = { "cat", "fish", "bird", "bunny" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	tuple.push_back("\'3\'");
	tuple.push_back("\'4\'");
	tuple.push_back("\'2\'");
	tuple.push_back("\'4\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'6\'");
	tuple.push_back("\'4\'");
	tuple.push_back("\'9\'");
	tuple.push_back("\'2\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'4\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'2\'");
	tuple.push_back("\'7\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'1\'");
	tuple.push_back("\'5\'");
	tuple.push_back("\'2\'");
	tuple.push_back("\'4\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'1\'");
	tuple.push_back("\'5\'");
	tuple.push_back("\'8\'");
	tuple.push_back("\'3\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	Relation result = naturalJoin(relOne, relTwo);
	string expectedStr = "  cat='1', dog='2', fish='5', bird='2', bunny='4'\n";
	expectedStr += "  cat='1', dog='2', fish='5', bird='8', bunny='3'\n";
	expectedStr += "  cat='6', dog='7', fish='4', bird='9', bunny='2'\n";
	if (expectedStr == result.toString())
	{
		cout << "Test 3: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 3: Failed" << endl;
	}
}

void Interpreter::testFour()
{
	//TEST 4 - Natural Join when no columns nor tuples are shared
	string tableName = "class";
	vector<string> columns = { "CS 235", "CS 236", "CS 240" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'10 AM\'");
	tuple.push_back("\'10 AM\'");
	tuple.push_back("\'11 AM\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'9 AM\'");
	tuple.push_back("\'12 PM\'");
	tuple.push_back("\'1 PM\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'8 AM\'");
	tuple.push_back("\'2 PM\'");
	tuple.push_back("\'3 PM\'");
	relOne.addTuple(tuple);
	tuple.clear();
	columns.clear();
	tableName = "class";
	columns = { "MATH 113", "MATH 313", "MATH 290" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	tuple.push_back("\'11 AM\'");
	tuple.push_back("\'1 PM\'");
	tuple.push_back("\'8 AM\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'10 AM\'");
	tuple.push_back("\'2 PM\'");
	tuple.push_back("\'2 PM\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'4 PM\'");
	tuple.push_back("\'12 PM\'");
	tuple.push_back("\'9 AM\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	Relation result = naturalJoin(relOne, relTwo);
	string expectedStr = "  CS 235='10 AM', CS 236='10 AM', CS 240='11 AM', MATH 113='10 AM', MATH 313='2 PM', MATH 290='2 PM'\n";
	expectedStr += "  CS 235='10 AM', CS 236='10 AM', CS 240='11 AM', MATH 113='11 AM', MATH 313='1 PM', MATH 290='8 AM'\n";
	expectedStr += "  CS 235='10 AM', CS 236='10 AM', CS 240='11 AM', MATH 113='4 PM', MATH 313='12 PM', MATH 290='9 AM'\n";
	expectedStr += "  CS 235='8 AM', CS 236='2 PM', CS 240='3 PM', MATH 113='10 AM', MATH 313='2 PM', MATH 290='2 PM'\n";
	expectedStr += "  CS 235='8 AM', CS 236='2 PM', CS 240='3 PM', MATH 113='11 AM', MATH 313='1 PM', MATH 290='8 AM'\n";
	expectedStr += "  CS 235='8 AM', CS 236='2 PM', CS 240='3 PM', MATH 113='4 PM', MATH 313='12 PM', MATH 290='9 AM'\n";
	expectedStr += "  CS 235='9 AM', CS 236='12 PM', CS 240='1 PM', MATH 113='10 AM', MATH 313='2 PM', MATH 290='2 PM'\n";
	expectedStr += "  CS 235='9 AM', CS 236='12 PM', CS 240='1 PM', MATH 113='11 AM', MATH 313='1 PM', MATH 290='8 AM'\n";
	expectedStr += "  CS 235='9 AM', CS 236='12 PM', CS 240='1 PM', MATH 113='4 PM', MATH 313='12 PM', MATH 290='9 AM'\n";
	if (expectedStr == result.toString())
	{
		cout << "Test 4: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 4: Failed" << endl;
	}
}

void Interpreter::testFive()
{
	//TEST 5 - Union when the columns of two relations are the same, but out of order
	string tableName = "numbers";
	vector<string> columns = { "A", "B", "C", "D" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'2\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'5\'");
	tuple.push_back("\'7\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'11\'");
	tuple.push_back("\'13\'");
	tuple.push_back("\'17\'");
	tuple.push_back("\'19\'");
	relOne.addTuple(tuple);
	tuple.clear();
	columns.clear();
	tableName = "numbersTwo";
	columns = { "D", "A", "C", "B" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	tuple.push_back("\'7\'");
	tuple.push_back("\'2\'");
	tuple.push_back("\'5\'");
	tuple.push_back("\'3\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'37\'");
	tuple.push_back("\'23\'");
	tuple.push_back("\'31\'");
	tuple.push_back("\'29\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	Relation result = uni(relOne, relTwo);
	string expectedStr = "  A='11', B='13', C='17', D='19'\n";
	expectedStr += "  A='2', B='3', C='5', D='7'\n";
	expectedStr += "  A='23', B='29', C='31', D='37'\n";
	if (expectedStr == result.toString())
	{
		cout << "Test 5: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 5: Failed" << endl;
	}
}

void Interpreter::testSix()
{
	//TEST 6 - Natural join when two relations share the same columns, but are out of order
	string tableName = "test";
	vector<string> columns = { "A", "B", "D", "C" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'1\'");
	tuple.push_back("\'2\'");
	tuple.push_back("\'3\'");
	tuple.push_back("\'4\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'5\'");
	tuple.push_back("\'6\'");
	tuple.push_back("\'7\'");
	tuple.push_back("\'8\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'9\'");
	tuple.push_back("\'10\'");
	tuple.push_back("\'11\'");
	tuple.push_back("\'12\'");
	relOne.addTuple(tuple);
	tuple.clear();
	columns.clear();
	tableName = "test";
	columns = { "D", "A", "C", "B" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	tuple.push_back("\'13\'");
	tuple.push_back("\'14\'");
	tuple.push_back("\'15\'");
	tuple.push_back("\'16\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'17\'");
	tuple.push_back("\'18\'");
	tuple.push_back("\'19\'");
	tuple.push_back("\'20\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	Relation result = naturalJoin(relOne, relTwo);
	string expectedStr = "";
	if (expectedStr == result.toString())
	{
		cout << "Test 6: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 6: Failed" << endl;
	}
}

void Interpreter::testSeven()
{
	//TEST 7 - Union with an empty relation
	string tableName = "Relation";
	vector<string> columns = { "C", "B", "E"};
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'1\'");
	tuple.push_back("\'4\'");
	tuple.push_back("\'144\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'9\'");
	tuple.push_back("\'16\'");
	tuple.push_back("\'25\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'169\'");
	tuple.push_back("\'8192\'");
	tuple.push_back("\'121\'");
	relOne.addTuple(tuple);
	tuple.clear();
	columns.clear();
	tableName = "RelationTwo";
	columns = { "C", "B", "E" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	Relation result = uni(relOne, relTwo);
	string expectedStr = "  C='1', B='4', E='144'\n";
	expectedStr += "  C='169', B='8192', E='121'\n";
	expectedStr += "  C='9', B='16', E='25'\n";
	if (expectedStr == result.toString())
	{
		cout << "Test 7: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 7: Failed" << endl;
	}
}

void Interpreter::testEight()
{
	//TEST 8 - Natural join of a relation with itself
	string tableName = "numList";
	vector<string> columns = { "func", "out" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'i^2\'");
	tuple.push_back("\'-1\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'ln(1)\'");
	tuple.push_back("\'0\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'cos(pi)\'");
	tuple.push_back("\'-1\'");
	relOne.addTuple(tuple);
	tuple.clear();
	Relation result = naturalJoin(relOne, relOne);
	string expectedStr = "  func='cos(pi)', out='-1'\n";
	expectedStr += "  func='i^2', out='-1'\n";
	expectedStr += "  func='ln(1)', out='0'\n";
	if (expectedStr == result.toString())
	{
		cout << "Test 8: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 8: Failed" << endl;
	}
}

void Interpreter::testNine()
{
	//TEST 9 - Natural join with an empty relation
	string tableName = "filled";
	vector<string> columns = { "A", "B" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'10\'");
	tuple.push_back("\'9\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'8\'");
	tuple.push_back("\'9\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'1\'");
	tuple.push_back("\'3\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'2\'");
	tuple.push_back("\'4\'");
	relOne.addTuple(tuple);
	tuple.clear();
	columns.clear();
	tableName = "empty";
	columns = { "C", "D" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	Relation result = naturalJoin(relOne, relTwo);
	string expectedStr = "";
	if (expectedStr == result.toString())
	{
		cout << "Test 9: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 9: Failed" << endl;
	}
}

void Interpreter::testTen()
{
	//TEST 10 - Natural join with three relations
	string tableName = "relationOne";
	vector<string> columns = { "A", "B", "C", "D" };
	Header newHeader = Header(columns);
	Relation relOne = Relation(tableName, newHeader);
	Tuple tuple;
	tuple.push_back("\'1\'");
	tuple.push_back("\'1\'");
	tuple.push_back("\'1\'");
	tuple.push_back("\'2\'");
	relOne.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'4\'");
	tuple.push_back("\'5\'");
	tuple.push_back("\'6\'");
	tuple.push_back("\'7\'");
	relOne.addTuple(tuple);
	tuple.clear();
	columns.clear();
	tableName = "relationTwo";
	columns = { "C", "D" };
	newHeader = Header(columns);
	Relation relTwo = Relation(tableName, newHeader);
	tuple.push_back("\'1\'");
	tuple.push_back("\'2\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'3\'");
	tuple.push_back("\'4\'");
	relTwo.addTuple(tuple);
	tuple.clear();
	columns.clear();
	Relation result = naturalJoin(relOne, relTwo);
	tableName = "relationThree";
	columns = { "E", "F", "G" };
	newHeader = Header(columns);
	Relation relThree = Relation(tableName, newHeader);
	tuple.push_back("\'3\'");
	tuple.push_back("\'4\'");
	tuple.push_back("\'5\'");
	relThree.addTuple(tuple);
	tuple.clear();
	tuple.push_back("\'5\'");
	tuple.push_back("\'8\'");
	tuple.push_back("\'1\'");
	relThree.addTuple(tuple);
	tuple.clear();
	columns.clear();
	result = naturalJoin(result, relThree);
	string expectedStr = "  A='1', B='1', C='1', D='2', E='3', F='4', G='5'\n";
	expectedStr += "  A='1', B='1', C='1', D='2', E='5', F='8', G='1'\n";
	if (expectedStr == result.toString())
	{
		cout << "Test 10: Passed" << endl;
	}
	else if (expectedStr != result.toString())
	{
		cout << "Test 10: Failed" << endl;
	}
}