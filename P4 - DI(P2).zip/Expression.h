#pragma once
#ifndef EXPRESSION_HPP
#define EXPRESSION_HPP

#include "Lexer.h"
#include "Operator.h"
#include "Parameter.h"
#include "Id.h"
#include "DLString.h"
#include <string>
#include <vector>
#include <typeinfo>

using namespace std;

class Expression : public Parameter //expression nonterminal
{
public:
	Expression();
	Expression(Lexer& lexer); //constructor that takes a lexer
	Expression(const Expression& expr);
	virtual ~Expression();

    void parseExpression(Lexer& lexer);

	void parseId(Lexer& lexer);

    void parseDLString(Lexer& lexer);

    Parameter* checkParamType(Lexer& lexer);

	string toString();

	string getVal() const;

	void clear(); //clears the vector of parameters
private:
    vector<Parameter*> parameters; //list of parameters for expression object
    Operator oper; //operator found while parsing
	string val; //value of expression
};
#endif
