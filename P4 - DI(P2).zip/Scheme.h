#pragma once
#ifndef SCHEME_HPP
#define SCHEME_HPP

#include "Lexer.h"
#include "Id.h"
#include <vector>
#include <string>

using namespace std;

class Scheme //scheme nonterminal
{
public:
	Scheme();
	Scheme(Lexer& parser);
	~Scheme();

	void parseScheme(Lexer& parser);

	void toString(string& result);

	vector<Id> getIds(); //gets the ids vector object
private:
	vector<Id> ids; //vector of ids
};

#endif