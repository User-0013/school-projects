#include "Token.h"

Token::Token(TokenType typeOfToken, int line, string valOfToken)
{
	type = typeOfToken;
	lineNum = line;
	val = valOfToken;
}

TokenType Token::getType()
{
	return type;
}

int Token::getLineNum()
{
	return lineNum;
}

string Token::getVal()
{
	return val;
}

string Token::toString()
{
    static const char* enumNames[] = { "UNDEFINED", "COMMA", "PERIOD", "Q_MARK", "LEFT_PAREN", "RIGHT_PAREN", "COLON", "COLON_DASH",
    "MULTIPLY", "ADD", "SCHEMES", "FACTS", "RULES", "QUERIES", "ID", "STRING", "COMMENT",
    "WHITESPACE", "END_OF_FILE" }; //strings of token types to put in tokens
	std::string tokenString;
	if (type != END_OF_FILE)
	{
		tokenString = "(";
		tokenString += enumNames[type];
	}
	else if (type == END_OF_FILE)
	{ 
		tokenString = "(";
		tokenString += "EOF"; 
	}
	tokenString += ",\"" + val;
	tokenString += "\"," + to_string(lineNum) + ")";
	return tokenString;
}
