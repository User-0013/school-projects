#pragma once
#ifndef FACT_HPP
#define FACT_HPP

#include "Lexer.h"
#include "Id.h"
#include "DLString.h"
#include <vector>
#include <string>
#include <set>

using namespace std;

class Fact //fact nonterminal
{
public:
	Fact();
	Fact(Lexer& lexer); //constructor that takes a lexer
	~Fact();

	void parseFact(Lexer& lexer);

	void toString(string& result);

	void getDomain(set<string>& domain);

	vector<DLString> getStrings(); //gets the vector of DLString objects

	string getFactName(); //gets the name of the Fact
private:
	vector<DLString> strings; //vector of dlstring objects
	string factName; //name of fact
};
#endif