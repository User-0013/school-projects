#pragma once
#ifndef DLSTRING_HPP
#define DLSTRING_HPP

#include "Lexer.h"
#include "Parameter.h"

using namespace std;

class DLString : public Parameter //dlstring nonterminal
{
public:
	DLString();
	DLString(Lexer& lexer); //constructor that takes a lexer
	DLString(const Parameter& oldString); //copy constructor
	virtual ~DLString();

	void parseDLString(Lexer& lexer);

    void parseExpression(Lexer& lexer);

	void parseId(Lexer& lexer);

	string toString();

	string getVal() const;

	void clear(); //clears the held dlstring
private:
	string dlString;
};

#endif
