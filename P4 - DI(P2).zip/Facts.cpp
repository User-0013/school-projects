#include "Facts.h"

Facts::Facts() {}
Facts::Facts(Lexer& lexer)
{
	parseFacts(lexer);
}
Facts::~Facts() {}

void Facts::parseFacts(Lexer& lexer)
{
	int initialPlace = 0;
	int loopCounter = -1;/*checks to make sure loop went at least zero times
	starts at -1 to indicate loop has not executed once.
	to figure out how many times loop has executed, take loopCounter + 1*/
	lexer.match(FACTS);
	lexer.match(COLON);
	initialPlace = lexer.getPlace(); //sets the place in list after checking for facts and colon
	while (true)
	{
		try
		{
			Fact fact(lexer);
			facts.push_back(fact);
			loopCounter++;
		}
		catch (Token error)
		{
			if (initialPlace == lexer.getPlace() || loopCounter != -1) //if the place is the same as initialPlace then there were no facts
				//or if the loop has executed more than once, then break because the fact is syntactically correct
			{
				break; //then continue parsing
			}
			else if (loopCounter >= 0) //indicates that zero or more facts were present
			{
				break;
			}
			else
			{
				throw error;
			}
		}
	}
}

void Facts::toString(string& result)
{
	result += "Facts(";
	result += to_string(facts.size()) + "):\n";
	for (unsigned int counter = 0; counter < facts.size(); counter++)
	{
		string factResult;
		result += "  ";
		facts[counter].toString(factResult);
		result += factResult + "\n";
	}
}

void Facts::getDomain(string& domain)
{
	for (unsigned int counter = 0; counter < facts.size(); counter++)
	{
		facts[counter].getDomain(domainList);
	}
	domain += "Domain(";
	domain += to_string(domainList.size());
	domain += "):\n";
	for (set<string>::iterator it = domainList.begin(); it != domainList.end(); ++it)
	{
		domain += "  " + (*it);
		domain += "\n";
	}
}

vector<Fact> Facts::getFact()
{
	return facts;
}