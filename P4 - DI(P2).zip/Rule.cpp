#include "Rule.h"

Rule::Rule() {}
Rule::Rule(Lexer& lexer)
{
	parseRule(lexer);
}
Rule::Rule(const Rule& oldRule)
{
	for (unsigned int counter = 0; counter < oldRule.preds.size(); counter++)
	{
		preds.push_back(new Predicate((*const_cast<Predicate*>(oldRule.preds[counter]))));
	}
	for (unsigned int counter = 0; counter < oldRule.headPreds.size(); counter++)
	{
		headPreds.push_back(oldRule.headPreds[counter]);
	}
}
Rule::~Rule()
{
	for (unsigned int counter = 0; counter < preds.size(); counter++)
	{
		if (preds[counter] != NULL)
		{
			delete preds[counter];
			preds[counter] = NULL;
		}
	}
}

void Rule::parseRule(Lexer& lexer)
{
	HeadPredicate headPredicate(lexer);
	headPreds.push_back(headPredicate);
	lexer.match(COLON_DASH);
	Predicate* predicate1 = new Predicate(lexer);
	preds.push_back(predicate1);
	while (true)
	{
		try
		{
			lexer.match(COMMA);
			Predicate* predicate2 = new Predicate(lexer);
			preds.push_back(predicate2);
		}
		catch (Token error)
		{
			if (error.getType() == PERIOD)
			{
				lexer.match(PERIOD);
				break;
			}
			else
			{
				clear(); //clear the predicate vector
				throw error;
			}
		}
	}
}

void Rule::toString(string& result)
{
	string predicate;
	vector<HeadPredicate>::iterator headIt = headPreds.begin();
	result += headIt->toString() + " :- ";
	for (unsigned int counter = 0; counter < preds.size() - 1; counter++)
	{
		preds[counter]->toString(predicate);
		result += predicate;
		result += ",";
		predicate.clear();
	}
	predicate.clear();
	preds[preds.size() - 1]->toString(predicate);
	result += predicate;
	result += ".";
}

void Rule::clear()
{
	for (unsigned int counter = 0; counter < preds.size(); counter++)
	{
		if (preds[counter] != NULL)
		{
			preds[counter]->clear();
			delete preds[counter];
			preds[counter] = NULL;
		}
	}
	if (!preds.empty())
	{
		preds.clear();
	}
}

vector<Predicate*> Rule::getPreds()
{
	return preds;
}

vector<HeadPredicate> Rule::getHeadPreds()
{
	return headPreds;
}