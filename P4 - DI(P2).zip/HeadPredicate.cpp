#include "HeadPredicate.h"

HeadPredicate::HeadPredicate() {}
HeadPredicate::HeadPredicate(Lexer& lexer)
{
	parseHeadPredicate(lexer);
}
HeadPredicate::HeadPredicate(const HeadPredicate& oldHeadPred)
{
	for (unsigned int counter = 0; counter < oldHeadPred.ids.size(); counter++)
	{
		ids.push_back(*shared_ptr<Id>(new Id(oldHeadPred.ids[counter])));
	}
}
HeadPredicate::~HeadPredicate() {}

void HeadPredicate::parseHeadPredicate(Lexer& lexer)
{
	Id id1(lexer);
	ids.push_back(id1);
	lexer.match(LEFT_PAREN);
	Id id2(lexer);
	ids.push_back(id2);
	while (true)
	{
		try
		{
			lexer.match(COMMA);
			Id id3(lexer);
			ids.push_back(id3);
		}
		catch (Token error)
		{
			if (error.getType() == RIGHT_PAREN)
			{
				break;
			}
			else
			{
				throw error;
			}
		}
	}
	lexer.match(RIGHT_PAREN);
}

string HeadPredicate::toString()
{
	string result;
	vector<Id>::iterator it = ids.begin();
	result += it->toString() + "(";
	++it;
	for (vector<Id>::iterator secondIt = it; secondIt != ids.end() - 1; ++secondIt)
	{
		result += secondIt->toString() + ",";
	}
	it = ids.end() - 1;
	result += it->toString() + ")";
	return result;
}

vector<Id> HeadPredicate::getIds()
{
	return ids;
}