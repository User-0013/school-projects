#include "Schemes.h"

Schemes::Schemes() {}

Schemes::Schemes(Lexer& lexer)
{
	parseSchemes(lexer);
}

Schemes::~Schemes() {}

void Schemes::parseSchemes(Lexer& lexer)
{
	int loopCounter = 0;//checks to make sure loop went at least one time
	lexer.match(SCHEMES);
	lexer.match(COLON);
	do
	{
		try
		{
			Scheme scheme(lexer);
			schemes.push_back(scheme);
			loopCounter++;
		}
		catch (Token error)
		{
			if (loopCounter >= 1) //indicates one or more schemes were present
			{
				break;
			}
			else
			{
				throw error;
			}
		}
	} while (true);
}

void Schemes::toString(string& result)
{
	result += "Schemes(";
	result += to_string(schemes.size());
	result += "):\n";
	for (unsigned int counter = 0; counter < schemes.size(); counter++)
	{
		string schemeResult;
		schemes[counter].toString(schemeResult);
		result += "  ";
		result += schemeResult + "\n";
		schemeResult.clear();
	}
}

vector<Scheme> Schemes::getScheme()
{
	return schemes;
}