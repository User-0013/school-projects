#include "DatalogProgram.h"

DatalogProgram::DatalogProgram() : lexer() {}

DatalogProgram::DatalogProgram(Lexer& lex) : lexer(lex)
{

}

DatalogProgram::~DatalogProgram() {}

void DatalogProgram::parseDatalogProgram(Lexer& parser)
{
	Schemes schemes(parser);
	schemesList.push_back(schemes);
	Facts facts(parser);
	factsList.push_back(facts);
	Rules rules(parser);
	rulesList.push_back(rules);
	Queries queries(parser);
	queriesList.push_back(queries);
    if(static_cast<unsigned int>(parser.getPlace()) != parser.getTokenVector().size() - 1)
    {
        throw parser.getTokenVector()[parser.getPlace()];
    }
    else
    {
	    toString(datalogProgram); //save the datalog program to a string
    }
}

void DatalogProgram::toString(string& result)
{
	//string result;
	vector<Schemes>::iterator schemesIt = schemesList.begin();
	schemesIt->toString(result);
	vector<Facts>::iterator factsIt = factsList.begin();
	factsIt->toString(result);
	vector<Rules>::iterator rulesIt = rulesList.begin();
	rulesIt->toString(result);
	vector<Queries>::iterator queriesIt = queriesList.begin();
	queriesIt->toString(result);
	factsIt->getDomain(result);
}

string DatalogProgram::getDatalogProgram()
{
	return datalogProgram;
}

Lexer& DatalogProgram::getLexerObj()
{
	return lexer;
}

void DatalogProgram::clear()
{
	for (unsigned int counter = 0; counter < rulesList.size(); counter++)
	{
		rulesList[counter].clear();
	}
	rulesList.clear();
}

vector<Rules> DatalogProgram::getRules()
{
	return rulesList;
}

vector<Schemes> DatalogProgram::getSchemes()
{
	return schemesList;
}

vector<Facts> DatalogProgram::getFacts()
{
	return factsList;
}

vector<Queries> DatalogProgram::getQueries()
{
	return queriesList;
}