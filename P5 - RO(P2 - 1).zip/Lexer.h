#pragma once
#ifndef LEXER_HPP
#define LEXER_HPP

#include<vector>
#include<string>
#include<stdexcept>
#include "InputStream.h"
#include "Token.h"
#include "FSM.h"

using namespace std;

class Lexer
{
public:
    Lexer();
	Lexer(string file);
	Lexer(const Lexer& lexer); //copy constructor
    ~Lexer() {}

	void advance();

	//Token currToken(int index); //takes index of and returns current token

	//void popCurrToken();

	vector<Token> getTokenVector(); //gets the vector of tokens

	int tokensLeft();

	void match(TokenType); //matches to see if the next token has the right type

	int getPlace(); //returns place

private:
	vector<Token> tokens; //list of tokens
	InputStream stream; //stream from the input file
	int place; //keeps track of the place in the list we are parsing
};

#endif
