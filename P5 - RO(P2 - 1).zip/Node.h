#pragma once
#ifndef NODE_HPP_
#define NODE_HPP_

using namespace std;

#include <string>
#include <set>

class Node
{
public:
	Node();
	Node(string headPred, unsigned int ruleNum);
	Node(const Node& old); //copy constructor
	~Node();

	string toString(); //gives a string representation of the nodes this node points to

	unsigned int getPointToSize() const; //gets the size of the pointTo set

	set<pair<int, Node*>> getPointTo() const; //gets the pointTo set

	bool pointToCount(int num) const; //similar to the count function in std::set, but specialized for set<pair<int, Node*>>
private:
	bool visited;
	string name;
	unsigned short int num; //number of the rule
	set<pair<int, Node*>> pointTo;
	friend class Graph;
	friend class DFSForest;
};
#endif