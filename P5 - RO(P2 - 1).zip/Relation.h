#pragma once
#ifndef RELATION_HPP
#define RELATION_HPP

#include"Tuple.h"
#include"Header.h"
#include<iostream>
#include<set>
#include<string>
#include<sstream>
#include<exception>

using namespace std;

class Relation
{
public:
	Relation();
	Relation(string name, Header header); //a constructor that defines a relation
	~Relation();
	//Relation& operator+=(const Relation& rel); //definition of += operator for relations

	Relation select(int firstColIndex, int secondColIndex); //selects the two columns desired

	Relation select(int colIndex, string value); //selects the column with the desired value

	Relation project(int colIndex); //projects the desired column of the relation

	Relation project(vector<int> indices); //projects the desired columns of the relation

	Relation rename(int colIndex, string newName); //renames a column in the relation

	Relation rename(vector<string> newHead); //renames the header of the relation

	void addTuple(Tuple tuple); //adds a relation

	string toString(); //toString method for the relation

	string getTableName(); //gets the name of the relation

	set<Tuple> getTuples(); //gets the set of tuples

	int getSizeOfTuples() const; //gets how many tuples there are

	vector<string> getHeaderCol() const; //gets the header columns

	//int find(vector<pair<string, char>> columns, string oldName); //finds and returns index if found of oldName, else throws out_of_range exception

	void test(); //hard coded tests for the select, project, and rename functions
private:
	string tableName;
	Header header;
	set<Tuple> tuples;
};

#endif
