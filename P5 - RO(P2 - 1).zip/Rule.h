#pragma once
#ifndef RULE_HPP
#define RULE_HPP

#include "Lexer.h"
#include "HeadPredicate.h"
#include "Predicate.h"
#include <vector>
#include <string>
#include <memory>

using namespace std;

class Rule //rule nonterminal
{
public:
	Rule();
	Rule(Lexer& lexer); //constructor that takes a lexer
	Rule(const Rule& oldRule); //copy constructor
	~Rule();

	void parseRule(Lexer& lexer);

	void toString(string& result);

	void clear(); //clears lists of head predicates and predicates

	vector<Predicate*> getPreds(); //gets the list of predicates

	vector<HeadPredicate> getHeadPreds(); //gets the list of head predicates
private:
	vector<HeadPredicate> headPreds; //list of head predicates
	vector<Predicate*> preds; //list of predicates
};
#endif
