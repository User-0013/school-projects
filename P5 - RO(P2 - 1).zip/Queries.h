#pragma once
#ifndef QUERIES_HPP
#define QUERIES_HPP

#include "Lexer.h"
#include "Query.h"
#include <vector>
#include <string>

using namespace std;

class Queries
{
public:
	Queries();
	Queries(Lexer& lexer); //constructor that takes a lexer
	~Queries();

	void parseQueries(Lexer& lexer);

	void toString(string& result);

	vector<Query> getQuery(); //gets the vector of Query objects
private:
	vector<Query> queries; //list of query objects
};
#endif