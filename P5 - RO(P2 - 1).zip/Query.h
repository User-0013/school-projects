#pragma once
#ifndef QUERY_HPP
#define QUERY_HPP

#include "Lexer.h"
#include "Predicate.h"
#include <vector>
#include <string>

using namespace std;

class Query //query nonterminal
{
public:
	Query();
	Query(Lexer& lexer);
	~Query();

	void parseQuery(Lexer& lexer);

	void toString(string& result);

	vector<Predicate> getPreds(); //gets the vector of Predicate objects
private:
	vector<Predicate> preds; //vector of predicate objects
};
#endif