#pragma once
#ifndef PARSER_HPP
#define PARSER_HPP

#include "Lexer.h"
#include "DatalogProgram.h"
#include <iostream>
#include <vector>

using namespace std;

class Parser
{
public:
	Parser(); //default constructor
	Parser(Lexer& lexer); //constructor with one parameter to take a lexer
	~Parser();

	void parse(Lexer& lexer); //begin parsing

	Lexer& getLexerObj(); //gets the lexer object held

	DatalogProgram getDatalogProg(); //gets the datalog program object held
private:
	Lexer lexer; //lexer object
	DatalogProgram datalogProg; //datalog program object
};

#endif
