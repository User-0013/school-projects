#ifndef TUPLE_HPP
#define TUPLE_HPP

#include<vector>
#include<string>
#include<sstream>

using namespace std;

class Tuple : public vector<string>
{
public:
	Tuple();
	~Tuple();

	string toString() const; //toString method for a tuple
};

#endif