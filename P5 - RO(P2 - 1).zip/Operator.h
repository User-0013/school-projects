#pragma once
#ifndef OPERATOR_HPP
#define OPERATOR_HPP

#include "Lexer.h"
#include <string>
#include <exception>

using namespace std;

class Operator //operator nonterminal
{
public:
	Operator();
	Operator(Lexer& lexer);
	~Operator();

	void parseOperator(Lexer& lexer);

	string toString();
private:
	char oper; //char that contains the operator
};
#endif
