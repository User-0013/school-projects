#pragma once
#ifndef PREDICATE_HPP
#define PREDICATE_HPP

#include "Lexer.h"
#include "Id.h"
#include "DLString.h"
#include "Expression.h"
#include "Parameter.h"
#include <vector>
#include <string>
#include <memory>
#include <typeinfo>

using namespace std;

class Predicate //predicate nonterminal
{
public:
	Predicate();
	Predicate(Lexer& lexer); //constructor that takes a lexer
	Predicate(const Predicate& oldPred); //copy constructor
	~Predicate();

	void parsePredicate(Lexer& lexer);

    Parameter* checkParamType(Lexer& lexer);

	void paramVectorDeepCopy(vector<Parameter*> paramShallow); //deep copys the shallow vector created into vector data memeber

	void toString(string& predicate);

	void clear(); //clears the vector of parameters

	vector<string> getPredicates(); //gets the list of predicates

	string getPredName(); //gets the name of the predicate
private:
    vector<Parameter*> parameters; //list of parameters
	string predName; //contains given predicate name
	vector<string> predicates; //list of predicates
};
#endif
