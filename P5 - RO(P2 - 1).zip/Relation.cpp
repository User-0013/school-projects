#include"Relation.h"

Relation::Relation() : tableName(), header(), tuples() {}
Relation::Relation(string name, Header inputHeader)
{
	tableName = name;
	header = inputHeader;
}
Relation::~Relation() {}

Relation Relation::select(int colIndex, string value)
{
	Header newHeader(header.getColumns());
	Relation chgRel(tableName, newHeader);
	for (set<Tuple>::iterator it = tuples.begin(); it != tuples.end(); ++it)
	{
		if ((*it)[colIndex] == value)
		{
			chgRel.addTuple((*it));
		}
	}
	return chgRel;
}

Relation Relation::select(int firstColIndex, int secondColIndex)
{
	if (static_cast<unsigned int>(firstColIndex) < header.getColumns().size() && static_cast<unsigned int>(secondColIndex) < header.getColumns().size())
	{
		Header newHeader(header.getColumns());
		Relation chgRel(tableName, newHeader);
		for (set<Tuple>::iterator it = tuples.begin(); it != tuples.end(); ++it)
		{
			if ((*it)[firstColIndex] == (*it)[secondColIndex])
			{
				chgRel.addTuple((*it));
			}
		}
		return chgRel;
	}
	else
	{
		return (*this);
	}
}

Relation Relation::project(int colIndex)
{
	if (static_cast<unsigned int>(colIndex) < header.getColumns().size()) //if the index asked for exists
	{
		vector<string> newCol; 
		newCol.push_back(header.getColumns()[colIndex]);
		Header newHeader(newCol);
		Relation chgRel(tableName, newHeader);
		for (set<Tuple>::iterator it = tuples.begin(); it != tuples.end(); ++it)
		{
			Tuple newTuple;
			newTuple.push_back((*it)[colIndex]);
			chgRel.addTuple(newTuple);
		}
		return chgRel;
	}
	else
	{
		return (*this);
	}
}

Relation Relation::project(vector<int> indices)
{
	vector<string> newCol;
	for (unsigned int counter = 0; counter < indices.size(); counter++)
	{
		if (static_cast<unsigned int>(indices[counter]) < header.getColumns().size())
		{
			newCol.push_back(header.getColumns()[indices[counter]]);
		}
	}
	Header newHeader(newCol);
	Relation chgRel(tableName, newHeader);
	for (set<Tuple>::iterator it = tuples.begin(); it != tuples.end(); ++it)
	{
		Tuple newTuple;
		for (unsigned int counter = 0; counter < indices.size(); counter++)
		{
			newTuple.push_back((*it)[indices[counter]]);
		}
		chgRel.addTuple(newTuple);
	}
	return chgRel;
}

Relation Relation::rename(int colIndex, string newName)
{
	if (static_cast<unsigned int>(colIndex) < header.getColumns().size()) //if the index asked for exists
	{
		Header newHeader(header.getColumns());
		newHeader.renameColumn(colIndex, newName);
		Relation chgRel(tableName, newHeader);
		for (set<Tuple>::iterator it = tuples.begin(); it != tuples.end(); ++it)
		{
			chgRel.addTuple((*it));
		}
		return chgRel;
	}
	else
	{
		return (*this);
	}
}

Relation Relation::rename(vector<string> newHead)
{
	if (newHead.size() == header.getColumns().size()) //the the size of the headers match
	{
		header = newHead;
		return (*this);
	}
	else
	{
		return (*this);
	}
}

void Relation::addTuple(Tuple tuple)
{
	tuples.insert(tuple);
}

string Relation::toString()
{
	stringstream stream;
	string result;
	for (set<Tuple>::iterator it = tuples.begin(); it != tuples.end(); ++it)
	{
		result += "  "; //remove if testing the test functions in Database class
		stream << (*it).toString();
		for (unsigned int counter = 0; counter < header.getColumns().size(); counter++)
		{
			if (counter != header.getColumns().size() - 1)
			{
				string temp;
				result += header.getColumns()[counter] + "='";
				getline(stream, temp, '\'');
				getline(stream, temp, '\'');
				result += temp + "', ";
			}
			else if (counter == header.getColumns().size() - 1)
			{
				string temp;
				result += header.getColumns()[counter] + "='";
				getline(stream, temp, '\'');
				getline(stream, temp, '\'');
				result += temp + "'";
			}
		}
		result += "\n";
	}
	return result;
}

string Relation::getTableName()
{
	return tableName;
}

set<Tuple> Relation::getTuples()
{
	return tuples;
}

int Relation::getSizeOfTuples() const
{
	return tuples.size();
}

vector<string> Relation::getHeaderCol() const
{
	return header.getColumns();
}

void Relation::test()
{
	string name = "snap";
	vector<string> schemeList = {"s","n","a","p"};
	tableName = name;
	Header testHead(schemeList);
	header = testHead;
	int colToChg = 1;
	string chgTo = "h";
	rename(colToChg, chgTo); //change the second column from "n" to "h"
	chgTo = "a";
	colToChg = 5;
	rename(colToChg, chgTo); //test to see if a nonexistent column will be changed
}
