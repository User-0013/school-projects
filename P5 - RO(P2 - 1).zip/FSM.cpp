#include "FSM.h"

void FSM::comma(InputStream& stream, vector<Token>& tokens)
{
	if (stream.getCurrChar() == ',')
	{
		Token tempToken = Token(COMMA, stream.getCurrLineNum(), ",");
		tokens.push_back(tempToken);
	}
}

void FSM::period(InputStream& stream, vector<Token>& tokens)
{
	if (stream.getCurrChar() == '.')
	{
		Token tempToken = Token(PERIOD, stream.getCurrLineNum(), ".");
		tokens.push_back(tempToken);
	}
}

void FSM::qMark(InputStream& stream, vector<Token>& tokens)
{
	if (stream.getCurrChar() == '?')
	{
		Token tempToken = Token(Q_MARK, stream.getCurrLineNum(), "?");
		tokens.push_back(tempToken);
	}
}

void FSM::leftParen(InputStream& stream, vector<Token>& tokens)
{
	if (stream.getCurrChar() == '(')
	{
		Token tempToken = Token(LEFT_PAREN, stream.getCurrLineNum(), "(");
		tokens.push_back(tempToken);
	}
}

void FSM::rightParen(InputStream& stream, vector<Token>& tokens)
{
	if (stream.getCurrChar() == ')')
	{
		Token tempToken = Token(RIGHT_PAREN, stream.getCurrLineNum(), ")");
		tokens.push_back(tempToken);
	}
}

void FSM::colonOrColonDash(InputStream& stream, vector<Token>& tokens)
{
	std::string parsedSoFar;
	bool loop = true;
	State currState = UNKNOWN;
	while (loop)
	{
		switch (stream.getCurrChar())
		{
		case ':': //colon state
			if (parsedSoFar.empty())
			{
				parsedSoFar += stream.getCurrChar();
				stream.advance();
				currState = COLON_S;
			}
			else if (!parsedSoFar.empty())
			{
				loop = false;
				stream.putBack();
			}
			break;
		case '-': //colon_dash state
			if (!parsedSoFar.empty())
			{
				parsedSoFar += stream.getCurrChar();
				stream.advance();
				currState = COLON_DASH_S;
			}
			break;
		default: loop = false; 
            stream.putBack(); break;
		}
	}
	createColonColonDashToken(stream, tokens, parsedSoFar, currState);
}

void FSM::createColonColonDashToken(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, State currState)
{
if (currState == COLON_S) //colon accepting state. make a new colon token
	{
		Token tempToken = Token(COLON, stream.getCurrLineNum(), parsedSoFar);
		tokens.push_back(tempToken);
		parsedSoFar.clear();
		currState = UNKNOWN;
	}
	else if (currState == COLON_DASH_S) //colon_dash accepting state. make a new colon_dash token
	{
		Token tempToken = Token(COLON_DASH, stream.getCurrLineNum(), parsedSoFar);
		tokens.push_back(tempToken);
		parsedSoFar.clear();
		currState = UNKNOWN;
	}
}

void FSM::multiply(InputStream& stream, vector<Token>& tokens)
{
	if (stream.getCurrChar() == '*')
	{
		Token tempToken = Token(MULTIPLY, stream.getCurrLineNum(), "*");
		tokens.push_back(tempToken);
	}
}

void FSM::add(InputStream& stream, vector<Token>& tokens)
{
	if (stream.getCurrChar() == '+')
	{
		Token tempToken = Token(ADD, stream.getCurrLineNum(), "+");
		tokens.push_back(tempToken);
	}
}

bool FSM::isSchemes(std::string& id, InputStream& stream, vector<Token>& tokens)
{
	if (id == SCHEMES_KEY)
	{
		Token tempToken = Token(SCHEMES, stream.getCurrLineNum(), id);
		tokens.push_back(tempToken);
		stream.putBack();
		id.empty();
		return true;
	}
	return false;
}

bool FSM::isFacts(std::string& id, InputStream& stream, vector<Token>& tokens)
{
	if (id == FACTS_KEY)
	{
		Token tempToken = Token(FACTS, stream.getCurrLineNum(), id);
		tokens.push_back(tempToken);
		stream.putBack();
		id.empty();
		return true;
	}
	return false;
}

bool FSM::isRules(std::string& id, InputStream& stream, vector<Token>& tokens)
{
	if (id == RULES_KEY)
	{
		Token tempToken = Token(RULES, stream.getCurrLineNum(), id);
		tokens.push_back(tempToken);
		stream.putBack();
		id.empty();
		return true;
	}
	return false;
}

bool FSM::isQueries(std::string& id, InputStream& stream, vector<Token>& tokens)
{
	if (id == QUERIES_KEY)
	{
		Token tempToken = Token(QUERIES, stream.getCurrLineNum(), id);
		tokens.push_back(tempToken);
		stream.putBack();
		id.empty();
		return true;
	}
	return false;
}

bool FSM::id(InputStream& stream, vector<Token>& tokens)
{
	std::string parsedSoFar;
	bool keyword = false;
	State currState = UNKNOWN;
    if(isdigit(stream.getCurrChar()))
    {
       return false; //if first char is a digit, do nothing and exit
    }
    else if (!isdigit(stream.getCurrChar()))
    {
	    do
	    {
	        if (isalnum(stream.getCurrChar()))
	    	{
		    	currState = ID_S;
		    	parsedSoFar += stream.getCurrChar();
		    	stream.advance();
		    }
		    else
		    {
		    	break;
	    	}
	    } while (true);
    }
	if (currState == ID_S)
	{
		keyword = isKeyword(parsedSoFar, stream, tokens);

		if (!keyword)
		{
			Token tempToken = Token(ID, stream.getCurrLineNum(), parsedSoFar);
			tokens.push_back(tempToken);
			stream.putBack();
			parsedSoFar.empty();
			currState = UNKNOWN;
		}
		return true;
	}
	return false;
}

bool FSM::isKeyword(std::string& id, InputStream& stream, vector<Token>& tokens)
{
        if (isSchemes(id, stream, tokens))
        {
            return true;
        }
		else if (isFacts(id, stream, tokens))
        {
            return true;
        }
		else if (isRules(id, stream, tokens))
        {
            return true;
        }
		else if (isQueries(id, stream, tokens))
        {
            return true;
        }
    return false;
}

void FSM::string(InputStream& stream, vector<Token>& tokens)
{
	std::string parsedSoFar;
	int stringLineStart = 0;
	bool loop = true;
	State currState = UNKNOWN;
	if (stream.getCurrChar() == '\'')
	{
		currState = READ_STRING;
		stringLineStart = stream.getCurrLineNum();
		parsedSoFar += '\'';
		stream.advance();
		while (loop)
		{
			if (stream.getCurrChar() == '\'')
			{
				currState = STRING_END;
				parsedSoFar += '\'';
				stream.advance();
				if (stream.getCurrChar() == '\'')
				{
					parsedSoFar += "\'";
					stream.advance();
					currState = READ_STRING;
				}
				else if (stream.getCurrChar() != '\'')
				{
					currState = STRING_END;
					loop = false;
				}
			}
			else if (stream.getCurrChar() != -1)
			{
				parsedSoFar += stream.getCurrChar();
				stream.advance();
			}
			else if (stream.getCurrChar() == -1) loop = false;
		}
	}
    createStringToken(stream, tokens, parsedSoFar, currState, stringLineStart);
}

void FSM::createStringToken(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, State currState, int lineStringStart)
{
	if (currState == STRING_END) //string accepting state
	{
		Token tempToken = Token(STRING, lineStringStart, parsedSoFar);
		tokens.push_back(tempToken);
		stream.putBack();
		parsedSoFar.empty();
		currState = UNKNOWN;
	}
	else if (currState != STRING_END)
	{
		Token tempToken = Token(UNDEFINED, lineStringStart, parsedSoFar);
		tokens.push_back(tempToken);
		parsedSoFar.empty();
		currState = UNKNOWN;
	}
}

void FSM::comment(InputStream& stream, vector<Token>& tokens)
{
	std::string parsedSoFar;
	int commentLineStart = 0;
	State currState = UNKNOWN;

	if (stream.getCurrChar() == '#')
	{
		currState = START_COMMENT;
		parsedSoFar += stream.getCurrCharWS();
		commentLineStart = stream.getCurrLineNum();
		stream.advance();
		processComment(stream, tokens, parsedSoFar, currState, commentLineStart);
	}
    //createCommentToken(tokens, parsedSoFar, currState, commentLineStart);
	//taken out to not include comment tokens to list
}

void FSM::processComment(InputStream& stream, vector<Token>& tokens, std::string&parsedSoFar, State& currState, int commentLineStart)
{
	    bool loop = true;
        while (loop)
		{
	        if (stream.getCurrCharWS() == '|')
			{
				parsedSoFar += stream.getCurrCharWS();
				multiLineComment(stream, tokens, parsedSoFar, commentLineStart, currState);
				loop = false;
			}
			else if (stream.getCurrCharWS() != '|' && stream.getCurrCharWS() != '\n' && stream.getCurrCharWS() != -1)
			{
				processSingleLine(stream, parsedSoFar, currState, loop);
			}
			else if (stream.getCurrChar() == '\n' || stream.getCurrChar() == -1)
			{
				currState = SINGLE_LINE_COMMENT;
				loop = false;
			}
        }
}

void FSM::processSingleLine(InputStream& stream, std::string& parsedSoFar, State& currState, bool& continueLoop)
{
    while(continueLoop)
    {
        if(stream.getCurrCharWS() != '\n' && stream.getCurrCharWS() != -1)
        {
            parsedSoFar += stream.getCurrCharWS();
            stream.advance();
        }
        else if(stream.getCurrCharWS() == '\n' || stream.getCurrCharWS() == -1)
        {
            currState = SINGLE_LINE_COMMENT;
            continueLoop = false;
        }
    }
}

void FSM::multiLineComment(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, int commentLineStart, State& currState)
{
	bool loop = true;
	currState = START_MULTI_LINE;
	stream.advance();

	while (loop)
	{
		if (stream.getCurrCharWS() != '|' && stream.getCurrCharWS() != '\r' && stream.getCurrCharWS() != -1)
		{
			parsedSoFar += stream.getCurrCharWS();
			stream.advance();
		}
		else if (stream.getCurrCharWS() == '\r')
		{
			stream.advance();
		}
		else if (stream.getCurrCharWS() == '|')
		{
			currState = AT_END_COMMENT;
			parsedSoFar += stream.getCurrCharWS();
			stream.advance();
			endMultiLine(stream, tokens, parsedSoFar, loop, currState);
		}
		else if (stream.getCurrChar() == -1) loop = false;
	}
}

void FSM::endMultiLine(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, bool& continueLoop, State& currState)
{
            if (stream.getCurrChar() == '#')
			{
				currState = MULTI_LINE_COMMENT;
				parsedSoFar += stream.getCurrCharWS();
				continueLoop = false;
			}
			else if (stream.getCurrChar() == '|')
			{
				parsedSoFar += stream.getCurrCharWS();
				stream.advance();
			}
}

void FSM::createCommentToken(vector<Token>& tokens, std::string& parsedSoFar, State currState, int lineCommentStart)
{
	if (currState == SINGLE_LINE_COMMENT) //single line comment accepting state
	{
		Token tempToken = Token(COMMENT, lineCommentStart, parsedSoFar);
		tokens.push_back(tempToken);
		parsedSoFar.empty();
		currState = UNKNOWN;
	}
	else if (currState == MULTI_LINE_COMMENT)
	{
		Token tempToken = Token(COMMENT, lineCommentStart, parsedSoFar);
		tokens.push_back(tempToken);
		parsedSoFar.empty();
		currState = UNKNOWN;
	}
	else if (currState != MULTI_LINE_COMMENT)
	{
		Token tempToken = Token(UNDEFINED, lineCommentStart, parsedSoFar);
		tokens.push_back(tempToken);
		parsedSoFar.empty();
		currState = UNKNOWN;
	}
}

void FSM::undefined(InputStream& stream, vector<Token>& tokens)
{
	if (stream.getCurrChar() != '\n')
	{
		std::string undefVal;
		undefVal = stream.getCurrChar();
		tokens.push_back(Token(UNDEFINED, stream.getCurrLineNum(), undefVal)); //anything not defined is undefined
	}
}
