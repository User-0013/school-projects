#include "Scheme.h"

Scheme::Scheme() {}

Scheme::Scheme(Lexer& parser)
{
	parseScheme(parser);
}

Scheme::~Scheme() {}

void Scheme::parseScheme(Lexer& parser)
{
	Id id(parser);
	ids.push_back(id);
	parser.match(LEFT_PAREN);
	Id id2(parser);
	ids.push_back(id2);
	while (true)
	{
		try
		{
			parser.match(COMMA);
			Id id3(parser);
			ids.push_back(id3);
		}
		catch (Token error)
		{
			if (error.getType() == RIGHT_PAREN)
			{
				break;
			}
			else
			{
				throw error;
			}
		}
	}
	parser.match(RIGHT_PAREN);
}

void Scheme::toString(string& result)
{
	result += ids.front().toString() + "(";
	for (unsigned int counter = 1; counter < ids.size() - 1; counter++)
	{
		result += ids[counter].toString();
		result += ",";
	}
	result += ids.back().toString() + ")";
}

vector<Id> Scheme::getIds()
{
	return ids;
}