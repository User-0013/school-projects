#pragma once
#ifndef HEADPREDICATE_HPP
#define HEADPREDICATE_HPP

#include "Lexer.h"
#include "Id.h"
#include <string>
#include <vector>
#include <memory>

using namespace std;

class HeadPredicate //headPredicate nonterminal
{
public:
	HeadPredicate();
	HeadPredicate(Lexer& lexer); //constructor that takes a lexer
	HeadPredicate(const HeadPredicate& oldHeadPred); //copy constructor
	~HeadPredicate();

	void parseHeadPredicate(Lexer& lexer);

	string toString();

	vector<Id> getIds(); //gets the list of ids
private:
	vector<Id> ids; //list of ids
};
#endif
