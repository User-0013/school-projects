#include "Parser.h"

Parser::Parser() : lexer(), datalogProg() /*: tokens(), place(0)*/ {} //default constructor
Parser::Parser(Lexer& lex) : lexer(lex), datalogProg(lex) //constructor that takes a vector of tokens
{

} 
Parser::~Parser() //destructor for parser
{} 

void Parser::parse(Lexer& lexer)
{
	try //try parsing
	{
		datalogProg.parseDatalogProgram(datalogProg.getLexerObj()); //start parsing at start nonterminal
		//cout << "Success!" << endl; //print success if input is found to be in the grammar
		//cout << datalogProgram.getDatalogProgram(); //print the datalog program
	}
	catch (Token token) //catch bad tokens
	{
		//cout << "Failure!" << endl << "  " << token.toString() << endl; //cout bad token
	}
}

Lexer& Parser::getLexerObj()
{
	return lexer;
}

DatalogProgram Parser::getDatalogProg()
{
	return datalogProg;
}