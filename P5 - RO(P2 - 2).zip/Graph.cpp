#include "Graph.h"

/*//Redefinition of getline using string instead of istream
//Definition below
namespace dan
{
	string getline(string& line, const char& delim);
}*/

Graph& Graph::operator=(Graph& rhs)
{
	this->swap(rhs);
	return *this;
}
void Graph::swap(Graph& old)
{
	using std::swap;
	swap(nodes, old.nodes);
	swap(inversed, old.inversed);
	swap(rules, old.rules);
}
Graph::Graph() {}
Graph::Graph(vector<Rule*> rulesList) : rules(rulesList), inversed(false)
{
	map<string, set<pair<int, Node*>>> tempNodes;
	for (unsigned int counter = 0; counter < rulesList.size(); counter++)
	{
		string predName = rulesList[counter]->getHeadPreds()[0].getIds().front().toString();
		Node* temp = new Node(predName, counter);
		tempNodes[predName].insert(pair<int, Node*>(temp->num, temp));
	}
	for (unsigned int counter = 0; counter < rulesList.size(); counter++)
	{
		Node* toPt = NULL;
		string headPred = rulesList[counter]->getHeadPreds()[0].getIds().front().toString();
		set<pair<int, Node*>>::iterator setIt = tempNodes[headPred].begin();
		for (unsigned int count = 0; count < rulesList[counter]->getPreds().size(); count++)
		{
			string predName = rulesList[counter]->getPreds()[count]->getPredName();
			while ((*tempNodes[headPred].find((*setIt))->second).visited)
			{
				++setIt;
			}
			toPt = tempNodes[headPred].find((*setIt))->second;
			if (tempNodes.count(predName))
			{
				set<pair<int, Node*>> toAdd = tempNodes[predName];
				for (set<pair<int, Node*>>::iterator it = toAdd.begin(); it != toAdd.end(); ++it)
				{
					toPt->pointTo.insert(*it);
				}
			}
		}
		toPt->visited = true;
	}
	popNodes(tempNodes);
	this->resetVisit();
}
Graph::Graph(const Graph& old) : rules(old.rules), inversed(old.inversed)
{
	map<int, set<int>> trackDupli;
	for (map<int, Node*>::const_iterator it = old.nodes.begin(); it != old.nodes.end(); ++it)
	{
		this->nodes[it->first] = new Node(*it->second);
		trackDupli[it->first];
		for (set<pair<int, Node*>>::iterator setIt = it->second->pointTo.begin(); setIt != it->second->pointTo.end(); ++setIt)
		{
			trackDupli[it->first].insert(setIt->first);
		}
	}
	for (map<int, set<int>>::iterator it = trackDupli.begin(); it != trackDupli.end(); ++it)
	{
		for (set<int>::iterator setIt = it->second.begin(); setIt != it->second.end(); ++setIt)
		{
			this->nodes[it->first]->pointTo.insert(pair<int, Node*>(*setIt, this->nodes[*setIt]));
		}
	}
}
Graph::~Graph() { clear(); }

void Graph::invert()
{
	map<int, set<int>> trackInvrs;
	for (map<int, Node*>::iterator it = nodes.begin(); it != nodes.end(); ++it)
	{
		for (set<pair<int, Node*>>::iterator setIt = it->second->pointTo.begin(); setIt != it->second->pointTo.end(); ++setIt)
		{
			trackInvrs[setIt->first].insert(it->first);
		}
		it->second->pointTo.clear();
	}
	for (map<int, Node*>::iterator it = nodes.begin(); it != nodes.end(); ++it)
	{
		for (set<int>::iterator setIt = trackInvrs[it->first].begin(); setIt != trackInvrs[it->first].end(); ++setIt)
		{
			nodes[it->first]->pointTo.insert(pair<int, Node*>(*setIt, nodes[*setIt]));
		}
	}
	inversed = true;
	/*for (map<int, Node*>::iterator it = nodes.begin(); it != nodes.end(); ++it)
	{
		for (set<pair<int, Node*>>::iterator setIt = it->second->pointTo.begin(); setIt != it->second->pointTo.end(); ++setIt)
		{
			//before[setIt->first]->pointTo.clear();
			before[setIt->first]->pointTo.insert(pair<int, Node*>(it->first, it->second));
		}
	}*/
	//return *this;
}

void Graph::popNodes(map<string, set<pair<int, Node*>>> tempNodes)
{
	for (map<string, set<pair<int, Node*>>>::iterator it = tempNodes.begin(); it != tempNodes.end(); ++it)
	{
		for (set<pair<int, Node*>>::iterator setIt = it->second.begin(); setIt != it->second.end(); ++setIt)
		{
			nodes[setIt->second->num] = setIt->second;
		}
	}
}

string Graph::toString()
{
	string result;
	if (inversed)
	{
		result += "Reverse ";
	}
	result += "Dependency Graph\n";
	for (map<int, Node*>::iterator it = nodes.begin(); it != nodes.end(); ++it)
	{
		result += "R" + to_string(it->second->num) + ":";
		result += it->second->toString() + "\n";
	}
	//result = sortToString(result);
	return result;
}

/*string Graph::sortToString(string toSort)
{
	string result;
	stringstream ss;
	ss << toSort;
	LinkedList<int> orderedNum;
	LinkedList<string> ordered;
	getline(ss, result);
	result.clear();
	while (getline(ss, result))
	{
		string temp = dan::getline(result, ':');
		temp = temp.replace(temp.begin(), temp.end() - 1, temp.begin() + 1, temp.end());
		temp.pop_back();
		if (orderedNum.size() != 0 && stoi(temp) > orderedNum.back())
		{
			orderedNum.insertTail(stoi(temp));
			ordered.insertTail(result);
		}
		else if (orderedNum.size() != 0 && stoi(temp) < orderedNum.front())
		{
			orderedNum.insertHead(stoi(temp));
			ordered.insertHead(result);
		}
		else if (orderedNum.size() == 0)
		{
			orderedNum.insertTail(stoi(temp));
			ordered.insertTail(result);
		}
		result.clear();
	}
	result = "Dependency Graph\n";
	for (list<string>::iterator it = ordered.begin(); it != ordered.end(); ++it)
	{
		result += *it + "\n";
	}****there was a end multiline comment here****
	return result;
}*/

void Graph::resetVisit()
{
	for (map<int, Node*>::iterator it = nodes.begin(); it != nodes.end(); ++it)
	{
		it->second->visited = false;
	}
}

void Graph::visitNode(Node* node)
{
	nodes[node->num]->visited = true;
}

bool Graph::allNodesVisited()
{
	bool result = false;
	for (map<int, Node*>::iterator it = nodes.begin(); it != nodes.end(); ++it)
	{
		if (!it->second->visited)
		{
			result = false;
			break;
		}
		else if (it->second->visited)
		{
			result = true;
		}
	}
	return result;
}

void Graph::clear()
{
	for (map<int, Node*>::iterator it = nodes.begin(); it != nodes.end(); ++it)
	{
		delete it->second;
		it->second = NULL;
	}
	nodes.clear();
	rules.clear();
}

vector<int> Graph::getRuleNum()
{
	vector<int> result;
	for (map<int, Node*>::iterator it = nodes.begin(); it != nodes.end(); ++it)
	{
		result.push_back(it->first);
	}
	return result;
}

map<int, Node*> Graph::getNodes()
{
	return nodes;
}

/*namespace dan
{
	//Get characters of string up to the delimiting character, then return
	//a new string with the characters found up until the delimiting character
	string getline(string& line, const char& delim)
	{
		string newLine;
		for (int counter = 0; counter < line.size(); counter++)
		{
			if (line[counter] == delim)
			{
				return newLine;
			}
			else
			{
				newLine.append(1, line[counter]);
			}
		}
	}
}*/