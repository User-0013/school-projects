#include"Database.h"

Database::Database() {}
Database::~Database() {}

unsigned int Database::getSizeTuples()
{
	unsigned int size = 0;
	for (map<string, Relation>::iterator it = this->begin(); it != this->end(); ++it)
	{
		size += it->second.getSizeOfTuples();
	}
	return size;
}

void Database::test()
{
	//TEST 1  - Rename the second column of the relation to "h"
	string name = "snap";
	vector<string> schemeList = { "s", "n", "a", "p" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'12345\'");
	aTuple.push_back("\'Charlie\'");
	aTuple.push_back("\'12 Apple St.\'");
	aTuple.push_back("\'555-1234\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'67890\'");
	aTuple.push_back("\'Lucy\'");
	aTuple.push_back("\'34 Pear Ave.\'");
	aTuple.push_back("\'555-5678\'");
	relate.addTuple(aTuple);
	origRel = relate;
	currRel = origRel;
	int colToChg = 1;
	string chgTo = "h";
	currRel = origRel.rename(colToChg, chgTo); //change the second column from "n" to "h"
	string expectedStr = "s='12345', h='Charlie', a='12 Apple St.', p='555-1234'\n";
	expectedStr += "s='67890', h='Lucy', a='34 Pear Ave.', p='555-5678'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 1: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 1: Failed" << endl;
	}
}

void Database::testTwo()
{
	//TEST 2 - Project the second and third columns of the relation
	string name = "table";
	vector<string> schemeList = { "A", "B", "C" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'1\'");
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'5\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'7\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	vector<int> colsToProj = { 1, 2 };
	currRel = origRel.project(colsToProj); //Projects the second and third columns
	string expectedStr = "B='4', C='5'\n";
	expectedStr += "B='4', C='7'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 2: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 2: Failed" << endl;
	}
}

void Database::testThree()
{
	//TEST 3 - Select the tuple that has '0' in column D
	string name = "table";
	vector<string> schemeList = { "A", "B", "C", "D" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'1\'");
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'5\'");
	aTuple.push_back("\'9\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'7\'");
	aTuple.push_back("\'0\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	int indexToSel = 3;
	string valToSel = "\'0\'";
	currRel = origRel.select(indexToSel, valToSel); //Select the value '0' from the last column D
	string expectedStr = "A='2', B='4', C='7', D='0'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 3: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 3: Failed" << endl;
	}
}

void Database::testFour()
{
	//TEST 4 - Mimic the Query: table('4',X,'5')?
	string name = "table";
	vector<string> schemeList = { "A", "B", "C" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'1\'");
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'3\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'2\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'3\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'6\'");
	aTuple.push_back("\'5\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	int indexToSel = 0;
	string valToSel = "\'4\'";
	currRel = origRel.select(indexToSel, valToSel); //First select '4' in the first column
	indexToSel = 2;
	valToSel = "\'5\'";
	currRel = currRel.select(indexToSel, valToSel); //Second, select '5' in the third column
	int colToProj = 1;
	currRel = currRel.project(colToProj); //Third, project the second column to prepare to rename it
	int colToRename = 0;
	string newName = "X";
	currRel = currRel.rename(colToRename, newName); //Lastly, renames the column from B to X
	string expectedStr = "X='6'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 4: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 4: Failed" << endl;
	}
}

void Database::testFive()
{
	//TEST 5 - selects the tuples where the first two entries in the tuples are equivalent
	string name = "table";
	vector<string> schemeList = { "A", "B", "C" , "D" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'1\'");
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'9\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'5\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'2\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'6\'");
	aTuple.push_back("\'5\'");
	aTuple.push_back("\'2\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	int indexSelOne = 0;
	int indexSelTwo = 1;
	currRel = origRel.select(indexSelOne, indexSelTwo); //Select the tuples where the first two entries are equivalent
	string expectedStr = "A='2', B='2', C='3', D='5'\n";
	expectedStr += "A='3', B='3', C='3', D='2'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 5: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 5: Failed" << endl;
	}
}

void Database::testSix()
{
	//TEST 6 - Project the third column of the relation
	string name = "table";
	vector<string> schemeList = { "A", "B", "C", "D", "E" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'1\'");
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'9\'");
	aTuple.push_back("\'6\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'5\'");
	aTuple.push_back("\'1\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'7\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'6\'");
	aTuple.push_back("\'5\'");
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'8\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	int colToProj = 2;
	currRel = origRel.project(colToProj); //Projects the third column C
	string expectedStr = "C='3'\n";
	expectedStr += "C='5'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 6: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 6: Failed" << endl;
	}
}

void Database::testSeven()
{
	//TEST 7 - Mimic the Query: SK(X,X)?
	string name = "SK";
	vector<string> schemeList = { "A", "B" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'a\'");
	aTuple.push_back("\'c\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'b\'");
	aTuple.push_back("\'c\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'b\'");
	aTuple.push_back("\'b\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'b\'");
	aTuple.push_back("\'c\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	int indexSelOne = 0;
	int indexSelTwo = 1;
	currRel = origRel.select(indexSelOne, indexSelTwo); //Select the tuples that have the same value in both columns
	int colToProj = 0;
	currRel = currRel.project(colToProj); //Project the first column since the tuples now have the same values in both columns
	int colToRename = 0;
	string newName = "X";
	currRel = currRel.rename(colToRename, newName); //Rename the column to X to find the answer to our Query
	string expectedStr = "X='b'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 7: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 7: Failed" << endl;
	}
}

void Database::testEight()
{
	//TEST 8 - Mimic the Query: Classes('CS235',X,Y)?
	string name = "Classes";
	vector<string> schemeList = { "Name", "PreReq", "Time" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'CS142\'");
	aTuple.push_back("\'N/A\'");
	aTuple.push_back("\'11AM\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'MATH112\'");
	aTuple.push_back("\'MATH110\'");
	aTuple.push_back("\'1PM\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'MATH313\'");
	aTuple.push_back("\'MATH112\'");
	aTuple.push_back("\'12PM\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'CS235\'");
	aTuple.push_back("\'CS142\'");
	aTuple.push_back("\'9AM\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'CS235\'");
	aTuple.push_back("\'CS142\'");
	aTuple.push_back("\'12PM\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	int indexToSel = 0;
	vector<int> colsToProj = {1, 2};
	currRel = origRel.select(indexToSel, "'CS235'"); //Select 'CS235' to find the class we are interested in
	currRel = currRel.project(colsToProj); //Project the second and third columns to find the prerequisites and times for CS235
	int indexRenameOne = 0;
	int indexRenameTwo = 1;
	string newNameOne = "X";
	string newNameTwo = "Y";
	currRel = currRel.rename(indexRenameOne, newNameOne); //Rename the first column to X
	currRel = currRel.rename(indexRenameTwo, newNameTwo); //Rename the second column to Y
	string expectedStr = "X='CS142', Y='12PM'\n";
	expectedStr += "X='CS142', Y='9AM'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 8: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 8: Failed" << endl;
	}
}

void Database::testNine()
{
	//TEST 9 - Mimic the Query: table(X,X,X,Y,Z)?
	string name = "table";
	vector<string> schemeList = { "A", "B", "C", "D", "E" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'1\'");
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'9\'");
	aTuple.push_back("\'6\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'5\'");
	aTuple.push_back("\'1\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'3\'");
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'7\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'4\'");
	aTuple.push_back("\'6\'");
	aTuple.push_back("\'5\'");
	aTuple.push_back("\'2\'");
	aTuple.push_back("\'8\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	vector<int> indicesToSel = { 0, 1, 2 };
	currRel = origRel.select(indicesToSel[0], indicesToSel[1]); //Select the first two columns to find the tuples where the first two entries are equivalent
	currRel = currRel.select(indicesToSel[1], indicesToSel[2]); //Select the second and third columns to find the tuples where the first three entries are equivalent by transitivity
	vector<int> indicesToRename = { 0, 1, 2, 3, 4};
	string newNameOne = "X";
	string newNameTwo = "Y";
	string newNameThree = "Z";
	currRel = currRel.rename(indicesToRename[0], newNameOne); //Rename the first three columns to X
	currRel = currRel.rename(indicesToRename[1], newNameOne);
	currRel = currRel.rename(indicesToRename[2], newNameOne);
	currRel = currRel.rename(indicesToRename[3], newNameTwo); //Rename the third column to Y
	currRel = currRel.rename(indicesToRename[4], newNameThree); //Rename the fourth column(last column) to Z
	vector<int> indicesToProj = { 2, 3, 4 };
	currRel = currRel.project(indicesToProj); //Project the second, third, and last columns to get the repective values of X,Y,Z
	string expectedStr = "X='3', Y='2', Z='7'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 9: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 9: Failed" << endl;
	}
}

void Database::testTen()
{
	//TEST 10 - Mimic the Query: ab('joe','jim')?
	string name = "ab";
	vector<string> schemeList = { "A", "B" };
	Header testHead(schemeList);
	Relation relate(name, testHead);
	Tuple aTuple;
	aTuple.push_back("\'joe\'");
	aTuple.push_back("\'bob\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'jim\'");
	aTuple.push_back("\'bob\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'joe\'");
	aTuple.push_back("\'jim\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	aTuple.push_back("\'bob\'");
	aTuple.push_back("\'bob\'");
	relate.addTuple(aTuple);
	aTuple.clear();
	origRel = relate;
	currRel = origRel;
	int indexSelOne = 0;
	int indexSelTwo = 1;
	string valSelOne = "'joe'";
	string valSelTwo = "'jim'";
	currRel = origRel.select(indexSelOne, valSelOne); //Select the tuples that have 'joe' as the first entry
	currRel = currRel.select(indexSelTwo, valSelTwo); //Select the tuples that have 'jim' as the second entry. This will answer our Query
	string expectedStr = "A='joe', B='jim'\n";
	if (expectedStr == currRel.toString())
	{
		cout << "Test 10: Passed" << endl;
	}
	else if (expectedStr != currRel.toString())
	{
		cout << "Test 10: Failed" << endl;
	}
}
