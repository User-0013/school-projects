#ifndef HEADER_HPP
#define HEADER_HPP

#include<vector>
#include<string>

using namespace std;

class Header
{
public:
	Header();
	Header(vector<string> schema); //constructor that takes a list of column names from the schema
	~Header();
	Header& operator+=(const Header& header); //definition of the += operator for Header

	vector<string> getColumns() const; //returns the columns data member

	void renameColumn(int index, string name); //renames the given column
private:
	vector<string> columns; //vector that holds the characters of the columns
};

#endif