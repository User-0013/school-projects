#include "Predicate.h"

Predicate::Predicate() {}
Predicate::Predicate(Lexer& lexer)
{
	parsePredicate(lexer);
}
Predicate::Predicate(const Predicate& oldPred)
{
	for (unsigned int counter = 0; counter < oldPred.parameters.size(); counter++)
	{
		string type = typeid((*oldPred.parameters[counter])).name();
		if (type == "class Id")
		{
			parameters.push_back(new Id((*const_cast<Parameter*>(oldPred.parameters[counter]))));
		}
		else if (type == "class DLString")
		{
			parameters.push_back(new DLString((*const_cast<Parameter*>(oldPred.parameters[counter]))));
		}
		else if (type == "class Expression")
		{
			parameters.push_back(new Expression((dynamic_cast<Expression&>(*oldPred.parameters[counter]))));
		}
	}
	for (unsigned int counter = 0; counter < oldPred.predicates.size(); counter++)
	{
		predicates.push_back(oldPred.predicates[counter]);
	}
	predName = oldPred.predName;
}
Predicate::~Predicate()
{
    for(unsigned int counter = 0; counter < parameters.size(); counter++)
    {
        if(parameters[counter] != NULL)
        {
            delete parameters[counter];
			parameters[counter] = NULL;
        }
    }
	parameters.clear();
}

void Predicate::parsePredicate(Lexer& lexer)
{
	Id id1(lexer);
	predName = id1.toString();
	lexer.match(LEFT_PAREN);
	Parameter* parameter1 = checkParamType(lexer);
    parameters.push_back(parameter1);
	predicates.push_back(parameter1->toString());
	while (true)
	{
		try
		{
			lexer.match(COMMA);
			Parameter* parameter2 = checkParamType(lexer);
            parameters.push_back(parameter2);
			predicates.push_back(parameter2->toString());
		}
		catch (Token error)
		{
			if (error.getType() == RIGHT_PAREN)
			{
				break;
			}
			else
			{
				clear(); //clear the parameters vector
				throw error;
			}
		}
	}
	lexer.match(RIGHT_PAREN);
}

Parameter* Predicate::checkParamType(Lexer& lexer)
{
	Parameter* parameter = NULL;
    try
    {
        parameter = new Expression(lexer);
        return parameter;
    }
    catch (exception& e)
    {
        throw lexer.getTokenVector()[lexer.getPlace()];
    }
    catch (Token error)
    {
		delete parameter;
		parameter = NULL;
        if (error.getType() == STRING || error.getType() == ID)
		{
			try
			{
				Parameter* parameter2 = new DLString(lexer);
                return parameter2;
			}
			catch (Token error)
			{
				if (error.getType() == ID)
				{
					Parameter* parameter3 = new Id(lexer);
                    return parameter3;
				}
				else
				{
					throw error;
				}
			}
		}
		else
		{
			throw error;
		}
    }
}

void Predicate::toString(string& predicate)
{
	predicate += predName + "(";
	for (unsigned int counter = 0; counter < predicates.size(); counter++)
	{
		if (counter != predicates.size() - 1)
		{
			predicate += predicates[counter] + ",";
		}
		else if (counter == predicates.size() - 1)
		{
			predicate += predicates[counter];
		}
	}
	predicate += ")";
}

void Predicate::clear()
{
	for (unsigned int counter = 0; counter < parameters.size(); counter++)
	{
		if (parameters[counter] != NULL)
		{
			parameters[counter]->clear();
			delete parameters[counter];
			parameters[counter] = NULL;
		}
	}
	parameters.clear();
}

vector<string> Predicate::getPredicates()
{
	return predicates;
}

string Predicate::getPredName()
{
	return predName;
}