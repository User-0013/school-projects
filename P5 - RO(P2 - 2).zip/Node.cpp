#include "Node.h"

/*Node& operator =(Node& rhs)
{
Node temp = Node(rhs);
this->swap(*this, temp);
return *this;
}
void swap(Node& ref, Node& old)
{
using std::swap;
swap(ref.visited, old.visited);
swap(ref.name, old.name);
swap(ref.num, old.num);
swap(ref.pointTo, old.pointTo);
}*/
/*bool operator <(const Node& n) const
{
return num < n.num;
}
Node& operator =(const Node& n)
{
visited = n.visited;
name = n.name;
num = n.num;
pointTo = n.pointTo;
return *this;
}
bool operator ()(const Node& n1, const Node& n2)
{
if (n1.num < n2.num) return true;
if (n1.num > n2.num) return false;
return (n1.num < n2.num);
}*/
Node::Node() :
visited(false), name(), num(0), pointTo() {}
Node::Node(string headPred, unsigned int ruleNum) :
visited(false), name(headPred), num(ruleNum), pointTo() {}
Node::Node(const Node& old) :
visited(old.visited), name(old.name), num(old.num)
{
	/*for (set<pair<int, Node*>>::const_iterator it = old.pointTo.begin(); it != old.pointTo.end(); ++it)
	{
	this->pointTo.insert(pair<int, Node*>(it->first, new Node(*it->second)));
	}*/
}
Node::~Node() {}

string Node::toString() //gives a string representation of the nodes this node points to
{
	string result;
	for (set<pair<int, Node*>>::iterator it = pointTo.begin(); it != pointTo.end(); ++it)
	{
		set<pair<int, Node*>>::iterator endAt = pointTo.end()--;
		if (it != --endAt)
			result += "R" + to_string(it->second->num) + ",";
		else
			result += "R" + to_string(it->second->num);
	}
	return result;
}

unsigned int Node::getPointToSize() const
{
	return pointTo.size();
}

set<pair<int, Node*>> Node::getPointTo() const
{
	return pointTo;
}

bool Node::pointToCount(int num) const
{
	bool result = false;
	for (set<pair<int, Node*>>::const_iterator it = pointTo.begin(); it != pointTo.end(); ++it)
	{
		if (it->first == num)
		{
			result = true;
			break;
		}
	}
	return result;
}