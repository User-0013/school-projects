#pragma once
#ifndef FACTS_HPP
#define FACTS_HPP

#include "Lexer.h"
#include "Fact.h"
#include <vector>
#include <string>
#include <set>

using namespace std;

class Facts //facts nonterminal
{
public:
	Facts();
	Facts(Lexer& lexer); //constructor that takes a lexer
	~Facts();

	void parseFacts(Lexer& lexer);

	void toString(string& result);

	void getDomain(string& domain);

	vector<Fact> getFact(); //gets the vector of Fact objects
private:
	vector<Fact> facts; //vector of fact objects
	set<string> domainList; //domain of datalog program
};

#endif