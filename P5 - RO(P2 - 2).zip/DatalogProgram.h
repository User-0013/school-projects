#pragma once
#ifndef DATALOGPROGRAM_HPP
#define DATALOGPROGRAM_HPP

#include "Lexer.h"
#include "Schemes.h"
#include "Facts.h"
#include "Rules.h"
#include "Queries.h"
#include <vector>
#include <string>

using namespace std;

class DatalogProgram //DatalogProgram start symbol
{
public:
	DatalogProgram();
	DatalogProgram(Lexer& parser); //constructor that takes a parser
	~DatalogProgram();

	void parseDatalogProgram(Lexer& parser); //start nonterminal

	void toString(string& result);

	string getDatalogProgram();

	Lexer& getLexerObj(); //gets the lexer object stored

	vector<Rules> getRules(); //gets the rules vector

	vector<Schemes> getSchemes(); //gets the schemes vector

	vector<Facts> getFacts(); //gets the facts vector

	vector<Queries> getQueries(); //gets the queries vector

	void clear(); //clears the list of rules
private:
	vector<Rules> rulesList; //list of rules
	vector<Schemes> schemesList; //list of schemes
	vector<Facts> factsList; //list of facts
	vector<Queries> queriesList; //list of queries
	string datalogProgram; //string containing the datalog program
	Lexer lexer; //lexer object to use in parsing
};

#endif