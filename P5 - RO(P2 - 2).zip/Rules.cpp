#include "Rules.h"

Rules::Rules() {}
Rules::Rules(Lexer& lexer)
{
	parseRules(lexer);
}
Rules::Rules(const Rules& oldRules)
{
	for (unsigned int counter = 0; counter < oldRules.rules.size(); counter++)
	{
		rules.push_back(new Rule((*const_cast<Rule*>(oldRules.rules[counter]))));
	}
}
Rules::~Rules()
{
	for (unsigned int counter = 0; counter < rules.size(); counter++)
	{
		if (rules[counter] != NULL)
		{
			delete rules[counter];
			rules[counter] = NULL;
		}
	}
	rules.clear();
}

void Rules::parseRules(Lexer& lexer)
{
	int initialPlace = 0;
	int loopCounter = -1;/*checks to make sure loop went at least zero times
	starts at -1 to indicate loop has not executed once.
	to figure out how many times loop has executed, take loopCounter + 1*/
	lexer.match(RULES);
	lexer.match(COLON);
	initialPlace = lexer.getPlace(); //sets the place in list after checking for rules and colon
	while (true)
	{
		try
		{
			Rule* rule = new Rule(lexer);
			rules.push_back(rule);
			loopCounter++;
		}
		catch (Token error)
		{
			if (initialPlace == lexer.getPlace() || loopCounter != -1) //if the place is the same as initialPlace then there were no rules
				//or if the loop has executed more than once, then break because the rule is syntactically correct
			{
				break;
			}
			else
			{
				throw error;
			}
		}
	}
}

void Rules::toString(string& result)
{
	string ruleResult;
	result += "Rules(";
	result += to_string(rules.size());
	result += "):\n";
	if (rules.size() != 0) //if the rules vector isn't empty, then go ahead and get all the info from the vector
	{
		for (vector<Rule*>::iterator it = rules.begin(); it != rules.end(); ++it)
		{
			result += "  ";
			(*it)->toString(ruleResult);
			result += ruleResult;
			result += "\n";
			ruleResult.clear();
		}
	}
}

void Rules::clear()
{
	for (unsigned int counter = 0; counter < rules.size(); counter++)
	{
		if (rules[counter] != NULL)
		{
			rules[counter]->clear();
			delete rules[counter];
			rules[counter] = NULL;
		}
	}
	rules.clear();
}

vector<Rule*> Rules::getRule()
{
	return rules;
}