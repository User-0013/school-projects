#include "Query.h"

Query::Query() {}
Query::Query(Lexer& lexer)
{
	parseQuery(lexer);
}
Query::~Query() {}

void Query::parseQuery(Lexer& lexer)
{
	Predicate predicate(lexer);
	preds.push_back(predicate);
	lexer.match(Q_MARK);
}

void Query::toString(string& result)
{
	string predResult;
	preds.front().toString(predResult);
	result += predResult + "?";
	predResult.clear();
}

vector<Predicate> Query::getPreds()
{
	return preds;
}