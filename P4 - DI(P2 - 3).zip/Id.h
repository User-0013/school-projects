#pragma once
#ifndef ID_HPP
#define ID_HPP

#include "Lexer.h"
#include "Parameter.h"
#include <string>

using namespace std;

class Id : public Parameter//id nonterminal
{
public:
	Id();
	Id(Lexer& lexer); //constructor that takes a lexer object
	Id(const Parameter& oldId); //copy constructor
	virtual ~Id();

	void parseId(Lexer& lexer);

    void parseDLString(Lexer& lexer);

    void parseExpression(Lexer& lexer);

	string toString();

	string getVal() const;

	void clear(); //clears the id held
private:
	string id; //holds the given id
};

#endif
