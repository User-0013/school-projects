#include "DLString.h"

DLString::DLString() {}
DLString::DLString(Lexer& lexer)
{
	parseDLString(lexer);
}
DLString::DLString(const Parameter& oldString)
{
	dlString = oldString.getVal();
}
DLString::~DLString() {}

void DLString::parseDLString(Lexer& lexer)
{
	lexer.match(STRING);
	dlString += lexer.getTokenVector().at(lexer.getPlace() - 1).getVal();
}

void DLString::parseExpression(Lexer& lexer) {}

void DLString::parseId(Lexer& lexer) {} //the two above functions have no need to be implemented since this is only an DLString

string DLString::toString()
{
	return dlString;
}

string DLString::getVal() const
{
	return dlString;
}

void DLString::clear()
{
	dlString.clear();
}