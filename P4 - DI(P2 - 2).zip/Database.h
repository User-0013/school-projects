#ifndef DATABASE_HPP
#define DATABASE_HPP

#include"Relation.h"
#include<map>

using namespace std;

class Database : public map<string, Relation>
{
public:
	Database();
	~Database();

	unsigned int getSizeTuples(); //gets the size of all the tuples in all the relations currently in the database

	void test(); //test cases for the Relation class

	void testTwo(); //test case for the Relation class

	void testThree(); //test case for the Relation class

	void testFour(); //test case for the Relation class

	void testFive(); //test case for the Relation class

	void testSix(); //test case for the Relation class

	void testSeven(); //test case for the Relation class

	void testEight(); //test case for the Relation class

	void testNine(); //test case for the Relation class

	void testTen(); //test case for the Relation class
private:
	Relation origRel;
	Relation currRel;
};

#endif