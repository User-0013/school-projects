#include "Expression.h"

Expression::Expression() {}
Expression::Expression(Lexer& lexer)
{
	parseExpression(lexer);
}
Expression::Expression(const Expression& expr)
{
	for (unsigned int counter = 0; counter < expr.parameters.size(); counter++)
	{
		string type = typeid((*expr.parameters[counter])).name();
		if (type == "class Id")
		{
			parameters.push_back(new Id((*const_cast<Parameter*>(expr.parameters[counter]))));
		}
		else if (type == "class DLString")
		{
			parameters.push_back(new DLString((*const_cast<Parameter*>(expr.parameters[counter]))));
		}
		else if (type == "class Expression")
		{
			parameters.push_back(new Expression((dynamic_cast<Expression&>(*expr.parameters[counter]))));
		}
	}
	val = expr.getVal();
	oper = expr.oper;
}
Expression::~Expression()
{
    for(unsigned int counter = 0; counter < parameters.size(); counter++)
    {
        if(parameters[counter] != NULL)
        {
            delete parameters[counter];
            parameters[counter] = NULL;
        }
    }
    parameters.clear();
}

void Expression::parseExpression(Lexer& lexer)
{
	Parameter* parameter1 = NULL;
	Parameter* parameter2 = NULL;
	try
	{
		lexer.match(LEFT_PAREN);
		parameter1 = checkParamType(lexer);
		Operator opr(lexer);
		parameter2 = checkParamType(lexer);
		lexer.match(RIGHT_PAREN);
		parameters.push_back(parameter1);
		parameters.push_back(parameter2);
		oper = opr;
	}
    catch (exception& e)
    {
        if (parameter1 != NULL)
		{
			delete parameter1;
		}
		if (parameter2 != NULL)
		{
			delete parameter2;
		}
		throw e;
    }
	catch (Token error)
	{
		if (parameter1 != NULL)
		{
			delete parameter1;
		}
		if (parameter2 != NULL)
		{
			delete parameter2;
		}
		throw error;
	}
}

void Expression::parseId(Lexer& lexer) {}

void Expression::parseDLString(Lexer& lexer) {} //the two above functions have no need to be implemented since this is only an expression

Parameter* Expression::checkParamType(Lexer& lexer)
{
    Parameter* parameter = NULL;
    Parameter* parameter2 = NULL;
    Parameter* parameter3 = NULL;
    try
    {
        parameter = new Expression(lexer);
		val = parameter->toString();
        return parameter;
    }
    catch (Token error)
    {
        if (error.getType() == STRING || error.getType() == ID)
		{
			try
			{
				parameter2 = new DLString(lexer);
				val = parameter2->toString();
                return parameter2;
			}
			catch (Token error)
			{
				if (error.getType() == ID)
				{
					parameter3 = new Id(lexer);
					val = parameter3->toString();
                    return parameter3;
				}
				else
				{
					throw error;
				}
			}
		}
		else
		{
			delete parameter;
			throw error;
		}
    }
}

string Expression::toString()
{
	string result;
	vector<Parameter*>::iterator it = parameters.begin();
	result += "(";
	result += (*it)->toString();
	it++;
	result += oper.toString();
	result += (*it)->toString();
	it++;
	result += ")";
	return result;
}

string Expression::getVal() const
{
	return val;
}

void Expression::clear()
{
	for (unsigned int counter = 0; counter < parameters.size(); counter++)
	{
		if (parameters[counter] != NULL)
		{
			parameters[counter]->clear();
			delete parameters[counter];
			parameters[counter] = NULL;
		}
	}
	parameters.clear();
}
