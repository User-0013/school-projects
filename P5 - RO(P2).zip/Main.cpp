#include "Lexer.h"
#include "Parser.h"
#include "Interpreter.h"
#include "Graph.h"
#include "DFSForest.h"
//#include <ctime>

using namespace std;

int main(int argv, char* argc[])
{
	Lexer lex(argc[1]);
	DatalogProgram datalogProg(lex);
	datalogProg.parseDatalogProgram(lex);
	Graph graph(datalogProg.getRules().front().getRule());
	cout << graph.toString() << endl;;
	Graph invertGraph = graph;
	invertGraph.invert();
	//cout << invertGraph.toString();
	vector<int> ruleNum = graph.getRuleNum();
	//DFSForest forOfOrig(graph, ruleNum);
	DFSForest forest(invertGraph, ruleNum);
	vector<int> toplogSort = forest.topologicalSort();
	DFSForest depenForest(graph, toplogSort);
	vector<set<int>> strongConnComp = depenForest.strongConnComp();
	Interpreter interpreter = Interpreter(datalogProg, strongConnComp, graph); //construct the interpreter with the given datalog program
	cout << "Query Evaluation" << endl;
	interpreter.ansQueries(); //answers the queries after evaluating the rules
	return 0;
}