#pragma warning(disable:4996)
#include "Lexer.h"
#include "Parser.h"
#include "Interpreter.h"
#include "Graph.h"
#include "DFSForest.h"
#include <ctime>

using namespace std;

int main(int argv, char* argc[])
{
	time_t tt;
	struct tm* ti;
	time(&tt);
	ti = localtime(&tt);
	int start = ti->tm_sec;
	int minStart = ti->tm_min;
	cout << "Main Start:" << asctime(ti) << endl;
	Lexer lex(argc[1]);
	DatalogProgram datalogProg(lex);
	datalogProg.parseDatalogProgram(lex);
	Graph graph(datalogProg.getRules().front().getRule());
	cout << graph.toString() << endl;;
	Graph invertGraph = graph;
	invertGraph.invert();
	//cout << invertGraph.toString();
	vector<int> ruleNum = graph.getRuleNum();
	//DFSForest forOfOrig(graph, ruleNum);
	DFSForest forest(invertGraph, ruleNum);
	vector<int> toplogSort = forest.topologicalSort();
	DFSForest depenForest(graph, toplogSort);
	vector<set<int>> strongConnComp = depenForest.strongConnComp();
	Interpreter interpreter = Interpreter(datalogProg, strongConnComp, graph); //construct the interpreter with the given datalog program
	cout << "Query Evaluation" << endl;
	interpreter.ansQueries(); //answers the queries after evaluating the rules
	time(&tt);
	ti = localtime(&tt);
	int end = ti->tm_sec;
	int minEnd = ti->tm_min;
	cout << endl << "Main End:" << to_string(minEnd - minStart) << "min " << to_string(end - start) << "sec" << endl;
	return 0;
}