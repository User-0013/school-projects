#ifndef LINKEDLIST_HPP_
#define LINKEDLIST_HPP_

#include "LinkedListInterface.h"
#include <sstream>
#include <stdexcept>

using namespace std;

template<typename T>
class LinkedList
{
	struct Node
	{
		T list_data;
		Node* next;

		Node(T data, Node* ptr) :
			list_data(data), next(ptr) {}

	};
public:
	LinkedList(): head(NULL), tail(NULL) {}
	virtual ~LinkedList() { clear(); }

	void insertSorted(T value)
	{
		if (head == NULL)
		{
			head = new Node(value, NULL);
			tail = head;
		}
		else if (head != NULL)
		{
			if (!dupliData(head, value))
			{
				Node* temp = head;
				while (temp != NULL)
				{
					if (temp->list_data < value)
					{
						Node* ptr = temp;
						temp = temp->next;
						ptr->next = new Node(value, temp);
					}
					else if (temp->list_data > value)
					{
						Node* ptr = temp;
						temp = temp->next;
						ptr->next = new Node(value, temp);
					}
				}
			}
		}
	}

	void insertHead(T value)
	{
		if (head == NULL)
		{
			head = new Node(value, NULL);
			tail = head;
		}
		else if (head != NULL)
		{
			if (!dupliData(head, value))
			{
				Node* temp = head;
				head = new Node(value, temp);
			}
		}
	}

	void insertTail(T value)
	{
		if (tail == NULL)
		{
			tail = new Node(value, NULL);
			head = tail;
		}
		else if (tail != NULL)
		{
			if (!dupliData(head, value))
			{
				Node* temp = tail;
				tail = new Node(value, NULL);
				temp->next = tail;
				//tail = temp->next;
			}
		}
	}

	void insertAfter(T value, T insertion_node)
	{
		Node* ptr = head;
		if (!dupliData(head, value))
		{
			while (ptr != NULL)
			{
				if (ptr->list_data == insertion_node)
				{
					if (ptr == tail)
					{
						ptr = NULL;
						insertTail(value);
					}
					else if (ptr != tail)
					{
						Node* temp = ptr;
						ptr = ptr->next;
						temp->next = new Node(value, ptr);
					}
				}
				else if (ptr->list_data != insertion_node)
				{
					ptr = ptr->next;
				}
			}
		}
	}

	void remove(T value)
	{
		bool loop = true;
		Node* ptr = head;
		while (loop)
		{
			if (ptr == NULL || ptr->next == NULL)
			{
				loop = false;
			}
			else if (value == head->list_data)
			{
				Node* temp = head;
				head = temp->next;
				temp->next = NULL;
				delete temp;
				temp = NULL;
				loop = false;
			}
			else if (ptr->next->list_data == value)
			{
				Node* temp = ptr->next;
				ptr->next = temp->next;
				temp->next = NULL;
				delete temp;
				temp = NULL;
				if (ptr->next == NULL)
				{
					tail = ptr;
				}
				loop = false;
			}
			else if (ptr->next->list_data != value)
			{
				ptr = ptr->next;
				loop = true;
			}
		}
	}

	void clear()
	{
		Node* ptr = head;
		while (head != NULL)
		{
			head = head->next;
			ptr->next = NULL;
			delete ptr;
			ptr = head;
		}
	}

	T at(int index)
	{
		int place = 0;
		Node* ptr = head;
		if (index > size() - 1 || index < 0)
		{
			throw out_of_range("Index is out of range");
		}
		else
		{
			for (place; place != index; place++)
			{
				ptr = ptr->next;
			}
		}
		return ptr->list_data;
	}

	int size()
	{
		int size = 0;
		Node* ptr = head;
		if (head == NULL)
		{
			size = 0;
		}
		else if (head != NULL)
		{
			for (size; ptr != NULL; size++)
			{
				ptr = ptr->next;
			}
		}
		return size;
	}

	string toString()
	{
		stringstream list;
		Node* ptr = head;
		if (ptr == NULL)
		{
			return "";
		}
		else if (ptr != NULL)
		{
			while (ptr != NULL)
			{
				if (ptr->next != NULL)
				{
					list << ptr->list_data << " ";
					ptr = ptr->next;
				}
				else if (ptr->next == NULL)
				{
					list << ptr->list_data;
					ptr = ptr->next;
				}
			}
		}
		return list.str();
	}

	T front() const
	{
		return head->list_data;
	}

	T back() const
	{
		return tail->list_data;
	}

	bool dupliData(Node* ptr, T data)
	{
		bool result = false;
		if (head == NULL)
		{
			result = false;
			return result;
		}
		else if (head != NULL)
		{
			Node* ptr = head;
			bool loop = true;
			while (loop && ptr != NULL)
			{
				if (ptr->list_data == data)
				{
					result = true;
					ptr = ptr->next;
					loop = false;
				}
				else if (ptr->list_data != data)
				{
					result = false;
					ptr = ptr->next;
					loop = true;
				}
			}
			return result;
		}
	}

private:
	Node* head;
	Node* tail;
};

#endif