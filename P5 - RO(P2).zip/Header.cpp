#include"Header.h"

Header::Header() {}
Header::Header(vector<string> name)
{
	columns = name;
}
Header::~Header() {}
Header& Header::operator+=(const Header& header)
{
	for (unsigned int counter = 0; counter < header.columns.size(); counter++)
	{
		this->columns.push_back(header.columns[counter]);
	}
	return (*this);
}

vector<string> Header::getColumns() const
{
	return columns;
}

void Header::renameColumn(int index, string name)
{
	if (static_cast<unsigned int>(index) < columns.size())
	{
		columns[index] = name;
	}
}
