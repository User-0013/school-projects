#pragma once
#ifndef TOKEN_HPP
#define TOKEN_HPP

#include<string>

using namespace std;

enum TokenType
{
	UNDEFINED, COMMA, PERIOD, Q_MARK, LEFT_PAREN, RIGHT_PAREN, COLON, COLON_DASH,
	MULTIPLY, ADD, SCHEMES, FACTS, RULES, QUERIES, ID, STRING, COMMENT,
	WHITESPACE, END_OF_FILE = -1
}; //enumeration of types of tokens with -1 being end of file and 0 being undefined

class Token
{
public:
	Token(TokenType type, int lineNum, string val);
	~Token() {}

	TokenType getType(); //gets current token type

	int getLineNum(); //gets the line number the token was created at

	string getVal(); //gets the value contained in the token

	string toString(); //to string method to print out tokens
private:
	TokenType type; //type of token
	string val; //value in token
	int lineNum; //line number the token was created at
};
#endif
