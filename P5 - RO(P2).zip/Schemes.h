#pragma once
#ifndef SCHEMES_HPP
#define SCHEMES_HPP

#include "Lexer.h"
#include "Scheme.h"
#include <vector>

using namespace std;

class Schemes //schemes nonterminal
{
public:
	Schemes();
	Schemes(Lexer& parser); //constructor that takes a parser object
	~Schemes();

	void parseSchemes(Lexer& parser);

	void toString(string& result);

	vector<Scheme> getScheme(); //gets the schemes vector object
private:
	vector<Scheme> schemes; //vector of scheme objects
};
#endif