#include "InputStream.h"

InputStream::InputStream() : currChar(), lineNum(1), file() {}

InputStream::InputStream(string fileName) : currChar(), lineNum(1), file() //initialize line number to start at 1
{
	file.open(fileName);
	if (!file.is_open())
	{
	}
	else
	{
	}
}

InputStream::~InputStream()
{
	file.close();
}

char InputStream::getCurrChar()
{
	if (isspace(file.peek()) && file.peek() != '\n' && file.peek() != ' ')
	{
		file.get();
	}
	return file.peek();
}

char InputStream::getCurrCharWS()
{
    if(file.peek() == '\r')
    {
        file.get();
    }
    return file.peek();
}

int InputStream::getCurrLineNum()
{
	return lineNum;
}

void InputStream::advance()
{
	if (file.peek() == '\n')
	{
		lineNum++;
		file.get();
	}
	else
	{
		file.get();
	}
}

void InputStream::putBack()
{
	file.unget();
}
