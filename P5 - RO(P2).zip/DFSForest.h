#pragma once
#ifndef DFSFOREST_HPP_
#define DFSFOREST_HPP_

using namespace std;

#include "Graph.h"
#include <stack>

class DFSForest : public Graph
{
public:
	DFSForest();
	DFSForest(Graph exeBefore, vector<int> ruleNum); //constructor that builds the DFS forest
	~DFSForest();

	void buildForest(Graph& exeBefore, vector<int>& rows, bool& newRoot, int& addPlace); //recursive function that executes DFS

	vector<int> topologicalSort(); //generates the topological ordering of our DFS forest

	void postOrdTraversal(stack<Node*>& numbering, set<pair<int, Node*>> pointSet, Node* node); //executes a post order tree traversal of our forest

	vector<set<int>> strongConnComp(); //finds the strongly connected components of our forest

	void resetVisit(); //resets the visit data member of all nodes

	void addNodeToEnd(pair<Node*, int> addAt, set<pair<int, Node*>>& pointSet, bool add); //adds a node to the end of the set of pointTo

	int getNextAdjNode(Graph& exeBefore, int row); //gets the next adjacent node in the adjacency list

	bool inSet(int node, set<pair<int, Node*>>& refSet, set<pair<int, Node*>>::iterator& it); //checks to see if the desired node is in the set

	void resetNodesInTree(Node*& node, set<pair<int, Node*>>& pointSet); //resets all the nodes in one tree of our forest

	void clear(); //clears the DFS forest

	void clearPointTo(set<pair<int, Node*>>& pointSet); //clears the pointTo sets recursively

	//void buildDFSForest(Graph& exeBefore, int& row, set<pair<int, Node*>>::iterator& col, bool& newRoot, bool& endRow);
	//recursive function that executes DFS

	//void advanceIt(Graph& exeBefore, int& row, set<pair<int, Node*>>::iterator& col, bool& endRow); //advances the col iterator
private:
	vector<Node*> rootsOfForest; //gives a pointer to the root of all the DFS forests
};

#endif