#include "Lexer.h"

Lexer::Lexer() {}

Lexer::Lexer(string file) : tokens(), stream(file), place(0)
{
	char type = stream.getCurrChar();
	if (type != -1)
	{
		while (type != -1)
		{
			bool idCreated = false;
			type = stream.getCurrChar();
			switch (type)
			{
			case ',': { FSM fsm;
				fsm.comma(stream, tokens); break; }
			case '.': { FSM fsm;
				fsm.period(stream, tokens); break; }
			case '?': { FSM fsm;
				fsm.qMark(stream, tokens); break; }
			case '(': { FSM fsm;
				fsm.leftParen(stream, tokens); break; }
			case ')': { FSM fsm;
				fsm.rightParen(stream, tokens); break; }
			case ':': { FSM fsm;
				fsm.colonOrColonDash(stream, tokens); break; }
			case '*': { FSM fsm;
				fsm.multiply(stream, tokens); break; }
			case '+': { FSM fsm;
				fsm.add(stream, tokens); break; }
			case '\'': { FSM fsm;
				fsm.string(stream, tokens); break; }
			case '#': { FSM fsm;
				fsm.comment(stream, tokens); break; }
			case ' ':
			case '\n': break;
			case -1: tokens.push_back(Token(END_OF_FILE, stream.getCurrLineNum(), "")); //end of file token
				break;
			default: FSM fsm;
				idCreated = fsm.id(stream, tokens); //try id
				if (!idCreated)
				{
					fsm.undefined(stream, tokens); //if not an id, then character must be undefined
				}
				break;
			}
			stream.advance();
		}
	}
	else if (type == -1)
	{
		tokens.push_back(Token(END_OF_FILE, stream.getCurrLineNum(), "")); //end of file token
	}
}

Lexer::Lexer(const Lexer& lexer)
{
	for (unsigned int counter = 0; counter < lexer.tokens.size(); counter++)
	{
		tokens.push_back(lexer.tokens[counter]);
	}
	place = lexer.place;
}

void Lexer::advance()
{
	stream.advance();
}

/*Token Lexer::currToken(int index)
{
	if (!tokens.empty())
	{
        //tempPtr= &tokens.front();
		return tokens.at(index); //returns token object at index provided
	}
	else if (tokens.empty())
	{
		throw out_of_range("No token present!");
	}
}*/

vector<Token> Lexer::getTokenVector()
{
	return tokens;
}

/*void Lexer::popCurrToken()
{
	if (tokens.empty()) {}
	else if (!tokens.empty())
	{
		tokens.pop();
	}
}*/

int Lexer::tokensLeft()
{
	return tokens.size();
}

void Lexer::match(TokenType type)
{
	if (tokens[place].getType() == type)
	{
		place++;
	}
	else
	{
		throw tokens.at(place);
	}
	/*switch (type)
	{
	case COMMA: break;
	case PERIOD: break;
	case Q_MARK: break;
	case LEFT_PAREN: break;
	case RIGHT_PAREN: break;
	case COLON: break;
	case COLON_DASH: break;
	case MULTIPLY: break;
	case ADD: break;
	case SCHEMES:{
	if (tokens[place].getType() == SCHEMES)
	{
	place++;
	}
	else
	{
	throw tokens.at(place);
	}
	break; }
	case FACTS: break;
	case RULES: break;
	case QUERIES: break;
	case ID: break;
	case STRING: break;
	case END_OF_FILE: break;
	default: throw tokens.at(place); break;
	}*/
}

int Lexer::getPlace()
{
	return place;
}
