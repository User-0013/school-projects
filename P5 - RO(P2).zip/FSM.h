#pragma once
#ifndef FSM_HPP
#define FSM_HPP

#include "InputStream.h"
#include "Token.h"
#include <vector>
#include <string>
#include <ctype.h>

using namespace std;

enum State {UNKNOWN, COLON_S, COLON_DASH_S, ID_S, READ_STRING, STRING_END,
		START_COMMENT, PROCESS_SINGLE_LINE, SINGLE_LINE_COMMENT, START_MULTI_LINE, AT_END_COMMENT,
		MULTI_LINE_COMMENT}; //state for the FSA. start states at 1 and let 0 be an undefined state

const std::string SCHEMES_KEY = "Schemes";
const std::string FACTS_KEY = "Facts";
const std::string RULES_KEY = "Rules";
const std::string QUERIES_KEY = "Queries"; //id keywords

class FSM
{
public:
	FSM() {}
	~FSM() {}

	void comma(InputStream& stream, vector<Token>& tokens);

	void period(InputStream& stream, vector<Token>& tokens);

	void qMark(InputStream& stream, vector<Token>& tokens);

	void leftParen(InputStream& stream, vector<Token>& tokens);

	void rightParen(InputStream& stream, vector<Token>& tokens);

	void colonOrColonDash(InputStream& stream, vector<Token>& tokens);

	void createColonColonDashToken(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, State currState);

	void multiply(InputStream& stream, vector<Token>& tokens);

	void add(InputStream& stream, vector<Token>& tokens);

	bool isSchemes(string& id, InputStream& stream, vector<Token>& tokens);

	bool isFacts(string& id, InputStream& stream, vector<Token>& tokens);

	bool isRules(string& id, InputStream& stream, vector<Token>& tokens);

	bool isQueries(string& id, InputStream& stream, vector<Token>& tokens);

	bool id(InputStream& stream, vector<Token>& tokens);

	bool isKeyword(std::string& id, InputStream& stream, vector<Token>& tokens);

	void string(InputStream& stream, vector<Token>& tokens);

	void createStringToken(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, State currState, int lineStringStart);

	void comment(InputStream& stream, vector<Token>& tokens);

	void processComment(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, State& currState, int commentLineStart);

    void processSingleLine(InputStream& stream, std::string& parsedSoFar, State& currState, bool& continueLoop);

	void multiLineComment(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, int commentLineStart, State& currState);

	void endMultiLine(InputStream& stream, vector<Token>& tokens, std::string& parsedSoFar, bool& continueLoop, State& currState);

	void createCommentToken(vector<Token>& tokens, std::string& parsedSoFar, State currState, int lineCommentStart);

	void undefined(InputStream& stream, vector<Token>& tokens);
};

#endif
