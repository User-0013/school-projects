#include "DFSForest.h"

DFSForest::DFSForest() {}
DFSForest::DFSForest(Graph exeBefore, vector<int> ruleNum)
{
	bool newRoot = false;
	int addPlace = INT_MAX;
	buildForest(exeBefore, ruleNum, newRoot, addPlace);
	resetVisit();
	//buildDFSForest(exeBefore, ruleNum.front(), exeBefore.getNodes()[ruleNum.front()]->pointTo.begin(), newRoot, endRow);
}
DFSForest::~DFSForest() { clear(); }

void DFSForest::buildForest(Graph& exeBefore, vector<int>& rows, bool& newRoot, int& addPlace)
{
	if (!rows.empty() && !exeBefore.getNodes()[rows.front()]->visited)
	{
		exeBefore.getNodes()[rows.front()]->visited = true;
		if (rootsOfForest.empty() || newRoot)
		{
			newRoot = false;
			rootsOfForest.push_back(new Node(*exeBefore.getNodes()[rows.front()]));
		}
		else
		{
			pair<Node*, int> addAt = pair<Node*, int>(new Node(*exeBefore.getNodes()[rows.front()]), addPlace);
			bool add = false;
			addNodeToEnd(addAt, rootsOfForest.back()->pointTo, add);
		}
		vector<int>::iterator it = rows.begin();
		addPlace = rows.front();
		if (getNextAdjNode(exeBefore, rows.front()) == INT_MAX)
		{
			rows.erase(it);
			newRoot = true;
		}
		else if (getNextAdjNode(exeBefore, rows.front()) != INT_MAX)
		{
			rows.insert(it, getNextAdjNode(exeBefore, rows.front()));
		}
		buildForest(exeBefore, rows, newRoot, addPlace);
	}
	else if (!rows.empty() && exeBefore.getNodes()[rows.front()]->visited)
	{
		if (!rows.empty())
		{
			vector<int>::iterator it = rows.begin();
			addPlace = rows.front();
			if (getNextAdjNode(exeBefore, rows.front()) == INT_MAX)
			{
				rows.erase(it);
				newRoot = true;
			}
			else if (getNextAdjNode(exeBefore, rows.front()) != INT_MAX)
			{
				rows.insert(it, getNextAdjNode(exeBefore, rows.front()));
				newRoot = false;
			}
			buildForest(exeBefore, rows, newRoot, addPlace);
		}
	}
}

vector<int> DFSForest::topologicalSort()
{
	vector<int> result;
	stack<Node*> numbering;
	for (vector<Node*>::iterator it = this->rootsOfForest.begin(); it != this->rootsOfForest.end(); ++it)
	{
		postOrdTraversal(numbering, (*it)->pointTo, (*it));
	}
	unsigned int stackSize = numbering.size();
	for (unsigned int counter = 0; counter < stackSize; counter++)
	{
		result.push_back(numbering.top()->num);
		numbering.pop();
	}
	return result;
}

void DFSForest::postOrdTraversal(stack<Node*>& numbering, set<pair<int, Node*>> pointSet, Node* node)
{
	if (pointSet.size() >= 1)
	{
		postOrdTraversal(numbering, pointSet.begin()->second->pointTo, pointSet.begin()->second);
		numbering.push(node);
	}
	else if (pointSet.size() == 0)
	{
		numbering.push(node);
	}
}

vector<set<int>> DFSForest::strongConnComp()
{
	stack<Node*> numbering;
	vector<set<int>> result;
	set<int> newComp;
	for (vector<Node*>::iterator it = this->rootsOfForest.begin(); it != this->rootsOfForest.end(); ++it)
	{
		postOrdTraversal(numbering, (*it)->pointTo, (*it));
		unsigned int stackSize = numbering.size();
		for (unsigned int counter = 0; counter < stackSize; counter++)
		{
			newComp.insert(numbering.top()->num);
			numbering.pop();
		}
		result.push_back(newComp);
		newComp.clear();
	}

	return result;
}

void DFSForest::resetVisit()
{
	for (unsigned int counter = 0; counter < rootsOfForest.size(); counter++)
	{
		resetNodesInTree(rootsOfForest[counter], rootsOfForest[counter]->pointTo);
	}
}

void DFSForest::addNodeToEnd(pair<Node*, int> addAt, set<pair<int, Node*>>& pointSet, bool add)
{
	if (!rootsOfForest.empty())
	{
		set<pair<int, Node*>>::iterator it;
		if (pointSet.size() == 0)
		{
			pointSet.insert(pair<int, Node*>(addAt.first->num, addAt.first));
		}
		else if (pointSet.size() >= 1 && !add)
		{
			if (inSet(addAt.second, pointSet, it))
			{
				add = true;
				addNodeToEnd(addAt, it->second->pointTo, add);
			}
			else
			{
				addNodeToEnd(addAt, pointSet.begin()->second->pointTo, add);
			}
		}
		else if (pointSet.size() >= 1 && add)
		{
			add = false;
			pointSet.insert(pair<int, Node*>(addAt.first->num, addAt.first));
		}
	}
}

int DFSForest::getNextAdjNode(Graph& exeBefore, int row)
{
	int result = INT_MAX;
	for (set<pair<int, Node*>>::iterator it = exeBefore.getNodes()[row]->pointTo.begin(); it != exeBefore.getNodes()[row]->pointTo.end(); ++it)
	{
		if (!it->second->visited)
		{
			result = it->first;
			break;
		}
	}
	return result;
}

bool DFSForest::inSet(int node, set<pair<int, Node*>>& refSet, set<pair<int, Node*>>::iterator& it)
{
	bool result = false;
	for (it = refSet.begin(); it != refSet.end(); ++it)
	{
		if (it->first == node)
		{
			result = true;
			break;
		}
	}
	return result;
}

void DFSForest::resetNodesInTree(Node*& node, set<pair<int, Node*>>& pointSet)
{
	if (pointSet.size() == 1)
	{
		node->visited = false;
		pointSet.begin()->second->visited = false;
		resetNodesInTree(node, pointSet.begin()->second->pointTo);
	}
}

void DFSForest::clear()
{
	for (unsigned int counter = 0; counter < rootsOfForest.size(); counter++)
	{
		clearPointTo(rootsOfForest[counter]->pointTo);
		delete rootsOfForest[counter];
		rootsOfForest[counter] = NULL;
	}
}

void DFSForest::clearPointTo(set<pair<int, Node*>>& pointSet)
{
	if (pointSet.size() >= 1)
	{
		for (set<pair<int, Node*>>::iterator it = pointSet.begin(); it != pointSet.end(); ++it)
		{
			clearPointTo(it->second->pointTo);
			delete it->second;
		}
		pointSet.clear();
	}
}

/*void DFSForest::buildDFSForest(Graph& exeBefore, int& row, set<pair<int, Node*>>::iterator& col, bool& newRoot, bool& endRow)
{
	if (row < exeBefore.getNodes().size() && !exeBefore.getNodes()[row]->visited)
	{
		exeBefore.getNodes()[row]->visited = true;
		col = exeBefore.getNodes()[row]->pointTo.begin();
		if (rootsOfForest.empty()) //if the roots of the forest are empty, then this is the first node in the forest
		{
			int origRow = row;
			rootsOfForest.push_back(new Node(*exeBefore.getNodes()[row]));
			advanceIt(exeBefore, row, col, endRow);
			set<pair<int, Node*>>::iterator temp = col;
			buildDFSForest(exeBefore, row, col, newRoot, endRow);
			col = temp;
			row = origRow;
			advanceIt(exeBefore, row, col, endRow);
			buildDFSForest(exeBefore, row, col, newRoot, endRow);
		}
		else if (!newRoot) //else we go to the last root and add a node
		{
			int origRow = row;
			rootsOfForest.back()->pointTo.insert(pair<int, Node*>(exeBefore.getNodes()[row]->num, new Node(*exeBefore.getNodes()[row])));
			advanceIt(exeBefore, row, col, endRow);
			set<pair<int, Node*>>::iterator temp = col;
			buildDFSForest(exeBefore, row, col, newRoot, endRow);
			col = temp;
			row = origRow;
			advanceIt(exeBefore, row, col, endRow);
			buildDFSForest(exeBefore, row, col, newRoot, endRow);
		}
		else if (newRoot)
		{
			rootsOfForest.push_back(new Node(*exeBefore.getNodes()[row]));
			newRoot = false;
			col = exeBefore.getNodes()[row]->pointTo.begin();
			buildDFSForest(exeBefore, row, col, newRoot, endRow);
		}
	}
	else if (row < exeBefore.getNodes().size() && exeBefore.getNodes()[row]->visited && endRow)
	{
		row++;
		newRoot = true;
		endRow = false;
		buildDFSForest(exeBefore, row, col, newRoot, endRow);
	}
	else if (!exeBefore.allNodesVisited())
	{
		row++;
		buildDFSForest(exeBefore, row, col, newRoot, endRow);
	}
	else if (!endRow)
	{

	}
}

void DFSForest::advanceIt(Graph& exeBefore, int& row, set<pair<int, Node*>>::iterator& col, bool& endRow)
{
	if (col != exeBefore.getNodes()[row]->pointTo.end())
	{
		row = col->first;
		++col;
	}
	else if (col == exeBefore.getNodes()[row]->pointTo.end())
	{
		endRow = true;
	}
}*/