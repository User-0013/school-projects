#include "Operator.h"

Operator::Operator() {}
Operator::Operator(Lexer& lexer)
{
	parseOperator(lexer);
}
Operator::~Operator() {}

void Operator::parseOperator(Lexer& lexer)
{
	try
	{
		lexer.match(ADD);
		oper = '+';
	}
	catch (Token error)
	{
		if (error.getType() == MULTIPLY)
		{
			lexer.match(MULTIPLY);
			oper = '*';
		}
		else
		{
			throw exception();
		}
	}
}

string Operator::toString()
{
	string result;
	result += oper;
	return result;
}
