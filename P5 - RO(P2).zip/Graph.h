#pragma once
#ifndef GRAPH_HPP_
#define GRAPH_HPP_

using namespace std;

#include <stddef.h>
#include <vector>
#include <map>
#include <set>
#include "Rule.h"
#include "Node.h"

class Graph
{
public:
	Graph& operator =(Graph& rhs);
	void swap(Graph& old);
	Graph();
	Graph(vector<Rule*> rules);
	Graph(const Graph& old); //copy constructor
	~Graph();

	void invert(); //inverts the edges in the graph

	//void topologicalSort(); //gives the topological sorting of the nodes in the graph

	//void strongConnComp(); //computes the stringly connected components of the graph

	void popNodes(map<string, set<pair<int, Node*>>> tempNodes); //populates nodes in order from an unordered map of rules

	string toString(); //gives a string representation of the dependency in the graph

	//string sortToString(string toSort); //sorts the result of the toString method to get rules in correct order

	void resetVisit(); //resets all the visited nodes to false

	void visitNode(Node* node); //visits the passed node

	bool allNodesVisited(); //checks whether all nodes were visited or not

	void clear(); //clears the graph of all nodes

	vector<int> getRuleNum(); //gets the numbers of the rules

	map<int, Node*> getNodes(); //gets the nodes of the graph

private:
	vector<Rule*> rules;
	map<int, Node*> nodes;
	bool inversed;
};

#endif