#include "Id.h"

Id::Id() {}
Id::Id(Lexer& parser)
{
	parseId(parser);
}
Id::Id(const Parameter& oldId)
{
	id = oldId.getVal();
}
Id::~Id() {}

void Id::parseId(Lexer& lexer)
{
	lexer.match(ID);
	id += lexer.getTokenVector().at(lexer.getPlace() - 1).getVal();
}

void Id::parseDLString(Lexer& lexer) {}

void Id::parseExpression(Lexer& lexer) {} //the two above functions have no need to be implemented since this is only an id

string Id::toString()
{
	return id;
}

string Id::getVal() const
{
	return id;
}

void Id::clear()
{
	id.clear();
}
