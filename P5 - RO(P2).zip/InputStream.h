#pragma once
#ifndef INPUTSTREAM_HPP
#define INPUTSTREAM_HPP

#include <sstream>
#include <fstream>
#include <iostream>
#include <ctype.h>

using namespace std;

class InputStream
{
public:
	InputStream(string fileName);
	InputStream();
	~InputStream();

	char getCurrChar(); //get the current character

	int getCurrLineNum();

    char getCurrCharWS(); //get the current character, including whitespace, expect \r

	void advance(); //advance to the next character in the stream

	void putBack(); //putsback the char just got
private:
	char currChar; //current character being read
	int lineNum; //line number of the current character being read
	ifstream file; //stores the data from the given file
};

#endif
