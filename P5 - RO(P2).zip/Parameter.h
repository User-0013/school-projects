#pragma once
#ifndef PARAMETER_HPP
#define PARAMETER_HPP

#include "Lexer.h"
//#include "Expression.h"
//#include "Id.h"
//#include "DLString.h"
#include <string>

using namespace std;

class Parameter //parameter nonterminal
{
public:
	Parameter() {}
	//Parameter(Lexer& lexer); //constructor that takes a lexer
	//Parameter(const Parameter&); //copy constructor
	virtual ~Parameter() {}

	//void parseParameter(Lexer& lexer);

    virtual void parseDLString(Lexer& lexer) = 0;

    virtual void parseId(Lexer& lexer) = 0;

    virtual void parseExpression(Lexer& lexer) = 0;

	virtual string toString() = 0;

	virtual string getVal() const = 0;

	virtual void clear() = 0;

	//virtual Parameter* clone() const = 0;

    //string typeOfParameter(Lexer& lexer);
};
#endif
