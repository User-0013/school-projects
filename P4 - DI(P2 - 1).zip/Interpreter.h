#pragma once
//#pragma warning(disable:4996)
#ifndef INTERPRETER_HPP
#define INTERPRETER_HPP

#include "Database.h"
#include "DatalogProgram.h"
//#include <ctime>

using namespace std;

class Interpreter
{
public:
	Interpreter(); //default constructor
	Interpreter(DatalogProgram datalogProg); //constructor that takes a datalog program
	~Interpreter();

	Relation ansQuery(vector<Predicate> preds, bool& qConst); //answers a single Query

	void ansQueries(); //answers all Queries

	Relation evalRule(vector<Predicate*> preds, HeadPredicate headPred); //evaluates the Rule and returns the resulting relation

	void evalRules(unsigned int& timesPassed, bool& chgd, unsigned int& preCoun);
	//evaluates the Rules and adds the new Facts to the database

	Relation uni(); //performs a union between two tables

	Relation naturalJoin(Relation first, Relation second); //performs a natural join between two tables

	Relation uni(Relation first, Relation second); //performs a union between two tables

	Relation selProjBeforeJoin(Relation rel, map<string, vector<int>> selectIn, vector<int> varCol);
	//selects any duplicate variables before performing join

	map<string, vector<int>> selectInput(vector<pair<string, int>>& constCol, vector<int>& varCol, set<string>& varSeenSoFar, vector<Predicate> preds);
	//gets the required input for a select

	map<string, vector<int>> selectInput(vector<int>& varCol, set<string>& varSeenSoFar, vector<string> columns);
	//gets the required input for a select

	set<pair<int, string>> projectInput(map<string, vector<int>> colVarSeenBefore, set<string> varSeenSoFar);
	//gets the required input for a project

	DatalogProgram getDatalogProg(); //gets the datalog program object

	bool varSeen(set<string> varSeenSoFar, string pred); //checks to see if we have seen the given variable yet or not

	bool allConst(vector<pair<string, int>> constCol, vector<int> varCol); //checks to see if our query is all constants or not

	vector<pair<int, int>> sharedVar(vector<string> first, vector<string> second); //checks to see if the two vectors share a variable

	vector<string> combHead(vector<string> colsOne, vector<string> colsTwo); //combines the headers of two relations

	void combTuples(Relation first, Relation second, Relation& newRel, vector<pair<int,int>> match, vector<int> varCol);
	//combines the tuples of two relations

	void combTuples(Relation first, Relation second, Relation& newRel); //combines the tuples of two relations

	Tuple projTuple(vector<int> col, Tuple tuple); //projects the desired columns of a tuple

	bool isJoinable(Tuple first, Tuple second, vector<pair<int,int>> match); //checks to see if two tuples can be combined

	vector<int> nonVarCol(vector<pair<int, int>> commonVar, unsigned int tupleSize); //gets the non variable columns of the second tuple

	Relation reorderCol(Relation toReorder, Relation reference); //reorders the columns of a relation with respect to another given relation

	void testOne(); //test case for the natural join and union

	void testTwo(); //test case for the natural join and union

	void testThree(); //test case for the natural join and union

	void testFour(); //test case for the natural join and union

	void testFive(); //test case for the natural join and union

	void testSix(); //test case for the natural join and union

	void testSeven(); //test case for the natural join and union

	void testEight(); //test case for the natural join and union

	void testNine(); //test case for the natural join and union

	void testTen(); //test case for the natural join and union
    
private:
	DatalogProgram datalogProg; //object that stores the datalog program
	Database database; //object that stores the database
};

#endif
