#pragma once
#ifndef RULES_HPP
#define RULES_HPP

using namespace std;

#include "Lexer.h"
#include "Rule.h"
#include <string>
#include <vector>

class Rules //rules nonterminal
{
public:
	Rules();
	Rules(Lexer& lexer);
	Rules(const Rules& rules); //copy constructor
	~Rules();

	void parseRules(Lexer& lexer);

	void toString(string& result);

	void clear(); //clears list of rules

	vector<Rule*> getRule(); //gets the list of rules
private:
	vector<Rule*> rules; //list of rules
};

#endif